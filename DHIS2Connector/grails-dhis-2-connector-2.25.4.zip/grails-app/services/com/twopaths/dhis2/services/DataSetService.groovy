package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional
import groovyx.net.http.ContentType

@Transactional
class DataSetService {

    final def PATH = "/dataSets"

    def apiService
    def messageSource
    def sqlViewService
    def propertiesService

    public final def FIELD_ID = "id"
    public final def FIELD_NAME = "name"
    public final def FIELD_SHORT_NAME = "shortName"
    public final def FIELD_USER = "user[id,name]"
    public final def FIELD_CREATED = "created"
    public final def FIELD_LAST_UPDATED = "lastUpdated"
    public final def FIELD_DATA_SET_ELEMENTS = "dataSetElements"
    public final def FIELD_DATA_ELEMENTS_CATEGORY_COMBO = "[id,dataElement[id,categoryCombo[name,categoryOptionCombos::isNotEmpty]]"

    def create(def auth, def dataSet, ApiVersion apiVersion = null) {

        log.debug ">>> dataSet: " + dataSet

        def result = apiService.post(auth, PATH, dataSet, [:], ContentType.JSON, apiVersion)

        log.debug "<<< dataSet, result: " + result

        return result
    }

    def delete(def auth, def dataSetId, ApiVersion apiVersion = null) {
        log.debug ">>> dataSet: " + dataSetId

        def path = "${PATH}/${dataSetId}"

        def result = apiService.delete(auth, path, [:], ContentType.JSON, apiVersion)

        log.debug "<<< dataSet, result: " + result

        return result

    }

    def findAll(def auth, ArrayList<String> fields = [], ApiVersion apiVersion = null) {

        def queryParams = [:]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def dataSets = apiService.get(auth, PATH, queryParams, null, apiVersion)?.data?.dataSets

        log.debug "<<< dataSets: " + dataSets

        return dataSets
    }

    def findAllWithReuploadInfo(def auth, ApiVersion apiVersion = null) {

        def dataSetFields = [
                FIELD_ID,
                FIELD_NAME,
                FIELD_SHORT_NAME,
                FIELD_USER,
                FIELD_CREATED,
                FIELD_LAST_UPDATED,
                FIELD_DATA_SET_ELEMENTS + FIELD_DATA_ELEMENTS_CATEGORY_COMBO
        ]

        def dataSets = findAll(auth, dataSetFields, apiVersion)

        def dataSetsWithData = findDataSetsWithData(auth, apiVersion)?.flatten()

        dataSets.each { dataSet ->
            dataSet.hasMetadata = dataSet.dataSetElements?.size() > 0
            dataSet.hasDisaggregations = false
            if (dataSet.hasMetadata) {
                dataSet.dataSetElements.find { dataSetElement ->
                    if (dataSetElement?.dataElement?.categoryCombo?.name != "default") {
                        dataSet.hasDisaggregations = dataSetElement.dataElement.categoryCombo?.categoryOptionCombos
                        return true
                    }
                }
            }
            dataSet.hasData = dataSet.id in dataSetsWithData
        }
        return dataSets
    }

    def findDataSetsWithData (def auth, def criteria = [:], ApiVersion apiVersion = null) {

        def sqlViewName = propertiesService.getProperties().getProperty('nep.sqlview.datasets.with.data.name', null)

        if (!sqlViewName) {
            throw new Exception("No application property specified for 'nep.sqlview.datasets.with.data.name'. " +
                    "Please create this property and create corresponding view in DHIS 2, then restart the application")
        }

        def sqlView = sqlViewService.findByName(auth, sqlViewName, apiVersion)

        if (!sqlView) {
            throw new Exception("Unable to find sql view with name ${sqlViewName}. Please ensure this has been created in DHIS 2")
        }

        // need to execute the view first in case the actual underlying db view was deleted
        sqlViewService.executeView(auth, sqlView.id, apiVersion)

        return sqlViewService.getViewData(auth, sqlView.id, criteria, apiVersion)
    }

    boolean dataSetHasData (def auth, def dataSetID, ApiVersion apiVersion = null) {
        def dbRows = findDataSetsWithData(auth, ["uid" : dataSetID], apiVersion)

        return (dbRows?.size() > 0)
    }

    def get(def auth, def id, ArrayList<String> fields = [], ApiVersion apiVersion = null) {

        def queryParams = [:]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def dataSet = apiService.get(auth, "${PATH}/${id}", queryParams, null,
                apiVersion)?.data

        log.debug "dataSet: " + dataSet

        return dataSet
    }

    def getFrequencies() {

        return [
                Daily : messageSource.getMessage("dataset.frequency.Daily", null, Locale.default),
                Weekly : messageSource.getMessage("dataset.frequency.Weekly", null, Locale.default),
                Monthly : messageSource.getMessage("dataset.frequency.Monthly", null, Locale.default),
                BiMonthly : messageSource.getMessage("dataset.frequency.BiMonthly", null, Locale.default),
                Quarterly : messageSource.getMessage("dataset.frequency.Quarterly", null, Locale.default),
                SixMonthly : messageSource.getMessage("dataset.frequency.SixMonthly", null, Locale.default),
                SixMonthlyApril : messageSource.getMessage("dataset.frequency.SixMonthlyApril", null, Locale.default),
                Yearly : messageSource.getMessage("dataset.frequency.Yearly", null, Locale.default),
                FinancialApril : messageSource.getMessage("dataset.frequency.FinancialApril", null, Locale.default),
                FinancialJuly : messageSource.getMessage("dataset.frequency.FinancialJuly", null, Locale.default),
                FinancialOct : messageSource.getMessage("dataset.frequency.FinancialOct", null, Locale.default)
        ]
    }

    def getOpenFuturePeriods() {

        return [
                "0" : messageSource.getMessage("label.no", null, Locale.default),
                "12" : messageSource.getMessage("label.yes", null, Locale.default)
        ]
    }
}
