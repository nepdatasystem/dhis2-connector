package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional
import groovyx.net.http.ContentType

@Transactional
class DataPruningService {

    final def PATH = "/maintenance/dataPruning"
    final def DATA_ELEMENT_SUB_PATH = "dataElements"

    def apiService

    def pruneDataElement(def auth, def dataElementId, ApiVersion apiVersion = null) {

        def result = apiService.post(auth, "${PATH}/${DATA_ELEMENT_SUB_PATH}/${dataElementId}",
                null, [:], ContentType.JSON, apiVersion )

        log.debug "prune, result: " + result

        return result
    }
}
