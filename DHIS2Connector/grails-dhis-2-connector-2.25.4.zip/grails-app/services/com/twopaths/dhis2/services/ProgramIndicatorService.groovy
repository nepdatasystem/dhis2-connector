package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional
import groovyx.net.http.ContentType

@Transactional
class ProgramIndicatorService {

    final def PATH = "/programIndicators"

    def apiService

    def findByProgramId(def auth, def programId, ApiVersion apiVersion = null) {

        def queryParams = [filter: "program.id:eq:${programId}"]

        def programIndicators = apiService.get(auth, "${PATH}", queryParams, null, apiVersion)?.data?.programIndicators

        return programIndicators
    }

    def delete(def auth, def programIndicatorId, ApiVersion apiVersion = null) {

        log.debug ">>> delete, programIndicatorId: " + programIndicatorId

        def path = "${PATH}/${programIndicatorId}"

        def result = apiService.delete(auth, path, [:], ContentType.JSON, apiVersion)

        log.debug "<<< delete, programIndicatorId, result: " + result

        return result
    }
}
