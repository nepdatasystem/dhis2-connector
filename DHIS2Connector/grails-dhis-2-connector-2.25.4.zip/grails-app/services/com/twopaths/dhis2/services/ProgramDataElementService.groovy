package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiStrategy
import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional
import groovyx.net.http.ContentType

@Transactional
class ProgramDataElementService {

    final def PATH = "/programDataElements"
    
    def apiService

    //TODO: POSTing with strategy=DELETE to API throws exception in DHIS 2. Have contacted DHIS 2 dev list and created
    // JIRA issue https://jira.dhis2.org/browse/DHIS2-1241.
    /*
    def bulkDelete (def auth, ArrayList<String> programDataElementIdsToDelete, ApiVersion apiVersion = null) {
        // to bulk delete, the body is POSTed with strategy=DELETE

        def query = [strategy: ApiStrategy.DELETE.value()]

        def programDataElementsToDelete = []

        programDataElementIdsToDelete.each { programDataElementId ->
            programDataElementsToDelete.add (["id" : programDataElementId])
        }

        def body = [programDataElements: programDataElementsToDelete]

        def result = apiService.post(auth, body, query, apiVersion)

        return result

    }
    */

    def delete (def auth, def programDataElementId, ApiVersion apiVersion = null) {

        def path = "${PATH}/${programDataElementId}"

        log.debug "programDataElement.delete"

        def result = apiService.delete (auth, path, [:], ContentType.JSON, apiVersion)

        return result
    }

    def find (def auth, queryParams = [:], ApiVersion apiVersion = null) {

        log.debug "programDataElements.find"

        def programDataElements = apiService.get(auth, "${PATH}", queryParams, null, apiVersion)?.data?.programDataElements

        return programDataElements
    }
}
