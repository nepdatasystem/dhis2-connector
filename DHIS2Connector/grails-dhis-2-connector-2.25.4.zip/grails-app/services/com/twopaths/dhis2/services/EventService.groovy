package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiStrategy
import com.twopaths.dhis2.api.ApiVersion
import com.twopaths.dhis2.api.Result
import groovyx.net.http.ContentType

class EventService {

    final def PATH = "/events"
    
    def apiService

    def create(def auth, def event, def query = [:], ApiVersion apiVersion = null) {

        def result = post(auth, event, query, apiVersion)

        log.debug "create, result: ${result}"

        return result
    }

    def post (def auth, def body, def query = [:], ApiVersion apiVersion = null) {

        def result = apiService.post(auth, PATH, body, query, ContentType.JSON, apiVersion)

        return result
    }

    // TODO: Fix when the response changes
    def update(def auth, def event, def eventId, def query = [:], ApiVersion apiVersion = null) {

        def result = apiService.put(auth, PATH, event, eventId, query, ContentType.JSON, apiVersion)

        def message = result?.message

        // TODO: Hack to cater for the fact that a 'response' is not returned so we just check for the content of the message field and construct fake data
        if (message?.startsWith("Import was successful.")) {
            result.importCount?.updated = 1
            result.succeeded = 1
            result.success = true

        } else {

            result.importCount?.ignored = 1
        }

        return result
    }

    def delete (def auth, def eventId, ApiVersion apiVersion = null) {

        def path = "${PATH}/${eventId}"

        def result = apiService.delete(auth, path, [:], ContentType.JSON, apiVersion)

        return result
    }

    def bulkDelete (def auth, ArrayList<Map<String,String>> eventsToDelete, ApiVersion apiVersion = null) {
        // to bulk delete, the body is POSTed with strategy=DELETE

        def query = [strategy: ApiStrategy.DELETE.value()]

        def body = [events: eventsToDelete]

        def result = post(auth, body, query, apiVersion)

        return result

    }

    def findByQuery(def auth, def query, ApiVersion apiVersion = null) {

        def events = apiService.get(auth, PATH, query, null, apiVersion)?.data

        return events
    }

    def findByProgramAndProgramStageId(def auth, def programId, def programStageId, def query = [:],
                                       ApiVersion apiVersion = null) {

        query <<  [program: programId, programStage: programStageId]

        return findByQuery(auth, query, apiVersion)
    }

    def findByProgramStageIdAndTrackedEntityInstanceId(def auth, def programStageId, def trackedEntityInstanceId,
                                                       ApiVersion apiVersion = null) {

        def queryParams = [programStage: programStageId, trackedEntityInstance: trackedEntityInstanceId]

        return findByQuery(auth, queryParams, apiVersion)
    }

    def get(def auth, def code, ArrayList<String> fields = [],
            ApiVersion apiVersion = null) {

        def queryParams = [:]

        if (code) {
            queryParams.put("filter", "code:eq:${code}")
        }

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        return findByQuery(auth, queryParams, apiVersion)

    }
}
