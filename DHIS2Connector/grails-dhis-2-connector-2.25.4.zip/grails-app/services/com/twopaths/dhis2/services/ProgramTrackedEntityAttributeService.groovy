package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional
import groovyx.net.http.ContentType

@Transactional
class ProgramTrackedEntityAttributeService {

    final def PATH = "/programTrackedEntityAttributes"

    def apiService

    def delete (def auth, def programTrackedEntityAttributeId, ApiVersion apiVersion = null) {

        def path = "${PATH}/${programTrackedEntityAttributeId}"

        def result = apiService.delete(auth, path, [:], ContentType.JSON, apiVersion)

        return result
    }

}
