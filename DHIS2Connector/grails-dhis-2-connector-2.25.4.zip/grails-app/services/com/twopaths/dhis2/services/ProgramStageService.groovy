package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiStrategy
import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional
import groovyx.net.http.ContentType

@Transactional
class ProgramStageService {

    final def PATH = "/programStages"
    final def PATH_PROGRAM_STAGE_DATA_ELEMENTS = "/programStageDataElements"
    
    def apiService
    
    def get(def auth, def programStageId, def query=[:],
            ApiVersion apiVersion = null) {

        log.debug "programStage.get, programStageId: ${programStageId}"
        
        def programStage = apiService.get(auth, "${PATH}/${programStageId}", query, null, apiVersion)?.data
        
        log.debug "programStage: ${programStage}"
        
        return programStage
    }
    
    def create(def auth, def programStage, ApiVersion apiVersion = null) {
        
        log.debug "programStage.create"

        def created = apiService.post(auth, PATH, programStage, [:], ContentType.JSON, apiVersion)
        
        log.debug "programStage: " + created
        
        return created
    }
    
    def update(def auth, def programStage, ApiStrategy apiStrategy = ApiStrategy.CREATE_AND_UPDATE,
               ApiVersion apiVersion = null) {

        def query = [strategy: apiStrategy.value()]
        
        log.debug "programStage.update"

        def result = apiService.put(auth, PATH, programStage, programStage.id, query, ContentType.JSON, apiVersion)

        return result
    }

    def delete(def auth, def programStageId, ApiVersion apiVersion = null) {
        log.debug ">>> program stage: " + programStageId

        def path = "${PATH}/${programStageId}"

        def result = apiService.delete(auth, path, [:], ContentType.JSON, apiVersion)

        log.debug "<<< program stage delete, result: " + result

        return result

    }

    def assignProgramStageDataElement(def auth, def programStageId, def programStageDataElementId,
                                      ApiVersion apiVersion = null) {

        def result = apiService.post(auth, "$PATH/${programStageId}$PATH_PROGRAM_STAGE_DATA_ELEMENTS/${programStageDataElementId}",
                null, [:], ContentType.JSON, apiVersion )

        return result
    }
    
    def findAll(def auth, def query=[fields: ":all"], ApiVersion apiVersion = null) {

        log.debug "programStage.findAll"

        def programStages = apiService.get(auth, "${PATH}", query, null, apiVersion)?.data

        return programStages
    }
    
    def findAllProgramStageDataElements(def auth, def programStageId, def queryParams = [:],
                                        ApiVersion apiVersion = null) {

        def programStageDataElements = apiService.get(auth, "$PATH/${programStageId}$PATH_PROGRAM_STAGE_DATA_ELEMENTS",
                queryParams, null, apiVersion)?.data
        
        return programStageDataElements
    }
}
