package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional
import groovyx.net.http.ContentType

@Transactional
class DashboardItemService {

    final def PATH = "/dashboardItems"

    def apiService

    /**
     * Finds all dashboard items that contain the supplied reportTable id
     *
     * @param auth DHIS 2 credentials
     * @param reportTableId Id of the report table to find dashboard items for
     * @param fields dashboard item fields to return
     * @param apiVersion DHIS 2 api version
     * @return found dashboard items if any
     */
    def findByReportTableId(def auth, def reportTableId, ArrayList<String> fields = [],
                            ApiVersion apiVersion = null) {

        def queryParams = [filter: "reportTable.id:eq:${reportTableId}"]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        return find(auth, queryParams, apiVersion)
    }

    /**
     * Finds all dashboard items that contain the supplied map id
     *
     * @param auth DHIS 2 credentials
     * @param mapId Id of the map to find dashboard items for
     * @param fields dashboard item fields to return
     * @param apiVersion DHIS 2 api version
     * @return found dashboard items if any
     */
    def findByMapId(def auth, def mapId, ArrayList<String> fields = [],
                            ApiVersion apiVersion = null) {

        def queryParams = [filter: "map.id:eq:${mapId}"]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        return find(auth, queryParams, apiVersion)
    }


    /**
     * Finds all dashboard items that contain the supplied chart id
     *
     * @param auth DHIS 2 credentials
     * @param chartId Id of the chart to find dashboard items for
     * @param fields dashboard item fields to return
     * @param apiVersion DHIS 2 api version
     * @return found dashboard items if any
     */
    def findByChartId(def auth, def chartId, ArrayList<String> fields = [],
                    ApiVersion apiVersion = null) {

        def queryParams = [filter: "chart.id:eq:${chartId}"]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        return find(auth, queryParams, apiVersion)
    }

    /**
     * Finds Dashboard Items based off supplied query params
     *
     * @param auth DHIS 2 credentials
     * @param query
     * @param apiVersion
     * @return Dashboard Items found
     */
    def find (def auth, def query = [:], ApiVersion apiVersion = null) {

        def dashboardItems = apiService.get(auth, "${PATH}", query, null, apiVersion)?.data?.dashboardItems

        log.debug "dashboardItems: " + dashboardItems

        return dashboardItems

    }

    /**
     * Deletes a dashboard item
     *
     * @param auth DHIS 2 credentials
     * @param dashboardItemId Id of the dashboard item to delete
     * @param apiVersion version of the DHIS 2 API to use
     * @return the Result of the deletion
     */
    def delete(def auth, def dashboardItemId, ApiVersion apiVersion = null) {

        log.debug ">>> dashboard item: " + dashboardItemId

        def path = "${PATH}/${dashboardItemId}"

        def result = apiService.delete(auth, path, [:], ContentType.JSON, apiVersion)

        log.debug "<<< dashboard item, result: " + result

        return result
    }

}
