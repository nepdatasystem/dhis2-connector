package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional
import groovyx.net.http.ContentType

@Transactional
class ChartService {

    final def PATH = "/charts"

    def apiService

    /**
     * Finds all charts that contain the supplied programDataElement
     *
     * @param auth DHIS 2 credentials
     * @param programDataElementId Id of the program data element to find charts for
     * @param fields Chart fields to return
     * @param apiVersion DHIS 2 api version
     * @return found charts if any
     */
    def findByProgramDataElementId (def auth, def programDataElementId, ArrayList<String> fields = [],
                                  ApiVersion apiVersion = null) {

        def queryParams = [filter: "dataDimensionItems.programDataElement.id:eq:${programDataElementId}"]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        return find(auth, queryParams, apiVersion)
    }

    /**
     * Finds all charts that contain the supplied programDataElement
     *
     * @param auth DHIS 2 credentials
     * @param programAttributeId Id of the program attribute to find charts for
     * @param fields Chart fields to return
     * @param apiVersion DHIS 2 api version
     * @return found charts if any
     */
    def findByProgramAttributeId (def auth, def programAttributeId, ArrayList<String> fields = [],
                                  ApiVersion apiVersion = null) {

        def queryParams = [filter: "dataDimensionItems.programAttribute.id:eq:${programAttributeId}"]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        return find(auth, queryParams, apiVersion)
    }

    /**
     * Finds Charts based off supplied query params
     *
     * @param auth DHIS 2 credentials
     * @param query
     * @param apiVersion
     * @return charts found
     */
    def find (def auth, def query = [:], ApiVersion apiVersion = null) {

        def charts = apiService.get(auth, "${PATH}", query, null, apiVersion)?.data?.charts

        log.debug "charts: " + charts

        return charts

    }

    /**
     * Deletes a chart
     *
     * @param auth DHIS 2 credentials
     * @param chartId Id of the chart to delete
     * @param apiVersion version of the DHIS 2 API to use
     * @return the Result of the deletion
     */
    def delete(def auth, def chartId, ApiVersion apiVersion = null) {

        log.debug ">>> chart: " + chartId

        def path = "${PATH}/${chartId}"

        def result = apiService.delete(auth, path, [:], ContentType.JSON, apiVersion)

        log.debug "<<< chart, result: " + result

        return result

    }

}
