package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiStrategy
import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional
import groovyx.net.http.ContentType

@Transactional
class EnrollmentService {

    final def PATH = "/enrollments"
    
    def apiService

    def create(def auth, def enrollment, def query = [:], ApiVersion apiVersion = null) {

        def result = apiService.post(auth, PATH, enrollment, query, ContentType.JSON, apiVersion)

        log.debug "create, result: " + result

        return result
    }

    def update(def auth, def enrollment, def query = [:], ApiStrategy apiStrategy = ApiStrategy.CREATE_AND_UPDATE,
               ApiVersion apiVersion = null) {

        query.put("strategy", ApiStrategy.CREATE_AND_UPDATE.value())

        def result = apiService.put(auth, PATH, enrollment, enrollment.id, query, ContentType.JSON, apiVersion)

        log.debug "update, result: " + result

        return result
    }

    def get(def auth, def code, ArrayList<String> fields = [],
            ApiVersion apiVersion = null) {

        def queryParams = [:]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def enrollment = apiService.get(auth, "${PATH}?code=${code}", queryParams, null, apiVersion)?.data

        log.debug "get, enrollment: " + enrollment

        return enrollment
    }
    
    def findByQuery(def auth, def query, ApiVersion apiVersion = null) {
        
        def enrollments = apiService.get(auth,  PATH, query, null, apiVersion)?.data

        log.debug "enrollments: " + enrollments
        
        return enrollments
    }
    
    def findByOrgUnitAndTrackedEntityInstance(def auth, def orgUnit, def trackedEntityInstanceId,
                                              ApiVersion apiVersion = null) {

        def queryParams = [ou: orgUnit, trackedEntityInstance: trackedEntityInstanceId, fields: ":all"]
        
        def enrollments = apiService.get(auth, "${PATH}", queryParams, null, apiVersion)?.data
        
        log.debug "enrollments: " + enrollments
        
        if (enrollments?.enrollments?.size() == 1) {
            return enrollments.enrollments[0]
        } else {
            log.error "No enrollments found for trackedEntityInstanceId: " + trackedEntityInstanceId
            return null
        }
    }
    
    def getLookup(def auth, ArrayList<String> fields = [":all"],
                  ApiVersion apiVersion = null) {

        def queryParams = [:]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def lookup = [:]

        def allEnrollments = []
        
        def enrollments = apiService.get(auth, "${PATH}", queryParams, null, apiVersion)?.data
        
        allEnrollments.addAll(enrollments.enrollments)
        
        // Create the lookup from the tracked entity attributes
        allEnrollments.each { enrollment ->
            lookup << [("${enrollment.code}".toString()): enrollment]
        }
        
        return lookup
    }
}
