package com.twopaths.dhis2.services

import org.springframework.security.authentication.AuthenticationServiceException

/**
 * Thrown if an authentication request could not be processed due to a connectivity issue with DHIS 2.
 *
 * Created by lcrees on 2016-05-24.
 */
public class AuthenticationDHIS2ConnectionException extends AuthenticationServiceException{
    AuthenticationDHIS2ConnectionException(String msg) {
        super(msg)
    }

    AuthenticationDHIS2ConnectionException(String msg, Throwable t) {
        super(msg, t)
    }
}
