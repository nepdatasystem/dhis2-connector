package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional
import groovyx.net.http.ContentType

@Transactional
class SqlViewService {

    final def PATH = "/sqlViews"

    def apiService

    /*
        These are the views that the system is relying on to determine whether datasets /programs have data or not.
        They need to be created upon instance set-up.

        nep.sqlview.datasets.with.data.name from nep.properties ("Data Sets With Data"):

            select distinct ds.uid from datasetelement dse inner join dataset ds on dse.datasetid=ds.datasetid where exists (select 1 from datavalue dv where dv.dataelementid=dse.dataelementid);

        nep.sqlview.programs.with.data.name ("Programs With Data")
        
            select distinct pr.uid from program pr inner join programinstance pi on pr.programid = pi.programid inner join trackedentityinstance tei on pi.trackedentityinstanceid = tei.trackedentityinstanceid;
            
        nep.sqlview.program.stages.with.data.name from nep.properties ("Program Stages With Data"):

            select distinct ps.uid from programstage ps inner join programstageinstance psi on ps.programstageid = psi.programstageid;
     */

    def findByName (def auth, def name, ApiVersion apiVersion = null) {

        def data = apiService.get(auth, PATH, [filter: "name:eq:${name}"], null, apiVersion)?.data

        log.debug "sql view ${} response: ${data}"

        def sqlView = data?.sqlViews?.size() > 0 ? data.sqlViews[0] : null

        return sqlView
    }

    def getViewData (def auth, def sqlViewId, def criteria = [:], ApiVersion apiVersion = null) {

        if (!sqlViewId) {
            return null
        }
        def queryString = null

        if (criteria) {
            // use as query string instead of query params map because map keys need to be unique
            def queryStringArray = []
            criteria.each { column, value ->
                queryStringArray << "criteria=${column}:${value}".toString()
            }
            queryString = queryStringArray.join("&")
        }

        def data = apiService.get(auth, PATH + "/${sqlViewId}/data", [:], queryString, apiVersion)?.data

        log.debug "sql view data for id ${sqlViewId} : ${data}"

        return data?.rows
    }

    def executeView (def auth, def sqlViewId, ApiVersion apiVersion = null) {

        if (!sqlViewId) {
            return null
        }

        def data = apiService.post(auth, PATH + "/${sqlViewId}/execute", [], [:], ContentType.ANY, apiVersion)?.data

        log.debug "sql view execution for id ${sqlViewId} : ${data}"

        return data

    }
}
