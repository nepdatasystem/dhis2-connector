package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiMergeMode
import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional
import groovyx.net.http.ContentType

@Transactional
class DataElementService {

    final def PATH = "/dataElements"
    final def DATASET_SUB_PATH = "dataSets"

    public final String ALL_FIELDS = ":all"
    public final String FIELD_VALUE_TYPE = "valueType"
    public final String FIELD_CATEGORY_COMBO = "categoryCombo[:identifiable]"
    public final String FIELD_ID = "id"
    
    def apiService

    def create(def auth, def dataElement, ApiVersion apiVersion = null) {

        log.debug ">>> dataElement: " + dataElement

        // remove the id
        dataElement.remove('id')

        def result = apiService.post(auth, PATH, dataElement, [:], ContentType.ANY, apiVersion)

        log.debug "<<< result: " + result

        return result
    }
    
    def update(def auth, def dataElement, ApiMergeMode mergeMode = ApiMergeMode.REPLACE,
               ApiVersion apiVersion = null) {

        def query = [mergeMode: mergeMode.value()]
        
        def result = apiService.put(auth, PATH, dataElement, dataElement.id, query, ContentType.JSON, apiVersion)
        
        log.debug "update, result: " + result
        
        return result
    }

    def delete(def auth, def dataElementId, ApiVersion apiVersion = null) {
        log.debug ">>> dataElement: " + dataElementId

        def path = "${PATH}/${dataElementId}"

        def result = apiService.delete(auth, path, [:], ContentType.JSON, apiVersion)

        log.debug "<<< dataElement, result: " + result

        return result

    }

    def get(def auth, def id, ArrayList<String> fields = [],
            ApiVersion apiVersion = null) {

        def queryParams = [:]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def dataElement = apiService.get(auth, "${PATH}/${id}", queryParams, null,
                apiVersion)?.data

        log.debug "dataElement: " + dataElement

        return dataElement
    }

    def findByName(def auth, def name, ArrayList<String> fields = [],
                   ApiVersion apiVersion = null) {

        def queryParams = [filter: "name:eq:${name}"]
        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def dataElements = apiService.get(auth, "${PATH}", queryParams, null, apiVersion)?.data?.dataElements

        log.debug "dataElements: " + dataElements

        def dataElement
        if (dataElements.size() == 1) {
            dataElement = dataElements[0]
        }


        return dataElement
    }

    def findByCode(def auth, def code, ArrayList<String> fields = [":all"],
                   ApiVersion apiVersion = null) {

        def queryParams = [filter: "code:eq:${code}"]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def dataElements = apiService.get(auth, "${PATH}", queryParams, null, apiVersion)?.data?.dataElements

        log.debug "dataElements: " + dataElements

        def dataElement
        if (dataElements.size() == 1) {
            dataElement = dataElements[0]
        }


        return dataElement
    }

    def findByUID(def auth, def UID, ArrayList<String> fields = [":all"],
                  ApiVersion apiVersion = null) {

        def queryParams = [:]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def dataElement = apiService.get(auth, "$PATH/${UID}", queryParams, null, apiVersion)

        return dataElement
    }

    def getLookup(def auth, ArrayList<String> fields = [":all"],
                  ApiVersion apiVersion = null) {

        def queryParams = [:]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def lookup = [:]
        
        def allDataElements = []
        
        def dataElements = apiService.get(auth, "${PATH}", queryParams, null, apiVersion)?.data
        
        if (dataElements) {
            allDataElements.addAll(dataElements.dataElements)
        
            // Create the lookup from the organization units
            allDataElements.each { dataElement ->
                lookup << [("${dataElement.code}".toString()): dataElement]
            }
        }
        return lookup
    }

    def assignDataSetToDataElement(def auth, def dataElementId, def dataSetId,
                                   ApiVersion apiVersion = null) {

        log.debug ">>> dataElement: " + dataElementId

        def json = apiService.post(auth, "${PATH}/${dataElementId}/${DATASET_SUB_PATH}/${dataSetId}",
                null, [:], ContentType.JSON, apiVersion )

        return json
    }

}
