package com.twopaths.api

import com.twopaths.dhis2.api.ApiResultParser
import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional

/**
 * A factory for returning corresponding parsers for specified Api Versions
 */
@Transactional
class ApiResultParserFactoryService {

    def apiResultParser223Service
    def apiResultParser224Service
    def apiResultParserDefaultService

    /**
     * Returns the appropriate parser for the specified api version
     *
     * @param apiVersion Api Version to get parser for
     * @return parser for the specified Api Version
     */
    ApiResultParser getParser(ApiVersion apiVersion) {

        switch (apiVersion) {
            case ApiVersion.DHIS2_VERSION_223 :
                return apiResultParser223Service;
                break;
            case ApiVersion.DHIS2_VERSION_224 :
                return apiResultParser224Service;
                break;
            case ApiVersion.DHIS2_DEFAULT_VERSION :
                return apiResultParserDefaultService
                break;

        }
    }
}
