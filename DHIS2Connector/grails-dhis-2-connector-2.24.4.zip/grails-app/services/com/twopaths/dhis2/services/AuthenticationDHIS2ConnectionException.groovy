package com.twopaths.dhis2.services

import org.springframework.security.authentication.AuthenticationServiceException

/**
 * Thrown if an authentication request could not be processed due to a connectivity issue with DHIS 2.
 */
public class AuthenticationDHIS2ConnectionException extends AuthenticationServiceException{

    /**
     * Constructor
     *
     * @param msg Error message
     */
    AuthenticationDHIS2ConnectionException(String msg) {
        super(msg)
    }

    /**
     * Constructor
     *
     * @param msg error message
     * @param t Exception itself
     */
    AuthenticationDHIS2ConnectionException(String msg, Throwable t) {
        super(msg, t)
    }
}
