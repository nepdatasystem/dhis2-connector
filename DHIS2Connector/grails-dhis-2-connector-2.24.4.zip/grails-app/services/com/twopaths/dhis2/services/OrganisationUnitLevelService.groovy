package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional

/**
 * Service to do OrganisationUnit CRUD with the DHIS 2 API
 */
@Transactional
class OrganisationUnitLevelService {

    final def PATH = "/organisationUnitLevels"

    def apiService

    /**
     * Creates a lookup map of OrganisationUnitLevel names by the organisationUnitLevel's level
     *
     * @param auth DHIS 2 Credentials
     * @param fields Fields requested in the response from the API
     * @param apiVersion ApiVersion to use
     * @return
     */
    def getLookup(def auth, ArrayList<String> fields = [":all"],
                  ApiVersion apiVersion = null) {

        def queryParams = [:]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def lookup = [:]

        // Get all the organisation units
        def organisationUnitLevels = apiService.get(auth, "${PATH}", queryParams, null,
                apiVersion)?.data?.organisationUnitLevels

        // Create the lookup from the organization unit Levels. Lookup by level to get the name
        organisationUnitLevels.each { organisationUnitLevel ->
            lookup << [("${organisationUnitLevel.level}".toString()): ("${organisationUnitLevel.name}".toString())]
        }

        lookup = lookup.sort {it.key}

        return lookup
    }

    /**
     * Retrieves a single organisationUnitLevel by its name
     *
     * @param auth DHIS 2 Credentials
     * @param name Name to find the organisationUnitLevel for
     * @param fields Fields requested in the response from the API
     * @param apiVersion ApiVersion to use
     * @return The organisationUnitLevel found if any
     */
    def getByName(def auth, def name, ArrayList<String> fields = [":all"],
                  ApiVersion apiVersion = null) {

        def queryParams = [filter: "name:eq:${name}"]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def organisationUnitLevels = apiService.get(auth, "${PATH}", queryParams, null,
                apiVersion)?.data?.organisationUnitLevels

        def orgUnitLevel

        if (organisationUnitLevels.size() == 1) {
            orgUnitLevel = organisationUnitLevels[0]
        }

        log.debug "orgUnitLevel: " + orgUnitLevel

        return orgUnitLevel
    }
}
