package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiMergeMode
import com.twopaths.dhis2.api.ApiStrategy
import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional
import groovyx.net.http.ContentType

/**
 * Service to do Program CRUD with the DHIS 2 API
 */
@Transactional
class ProgramService {

    final def PATH = "/programs"

    def apiService

    /**
     * Creates a Program via the DHIS 2 API
     *
     * @param auth DHIS 2 Credentials
     * @param program The program to create
     * @param apiVersion ApiVersion to use
     * @return The Result of the API creation
     */
    def create(def auth, def program, ApiVersion apiVersion = null) {

        def result = apiService.post(auth, PATH, program, [:], ContentType.JSON, apiVersion)

        log.debug "program: " + result

        return result
    }

    /**
     * Updates a Program via the DHIS 2 API
     *
     * @param auth DHIS 2 Credentials
     * @param program The program to update
     * @param mergeMode The mergeMode to use for the update
     * @param apiStrategy The apiStrategy to use for the update
     * @param apiVersion ApiVersion to use
     * @return The Result of the API update
     */
    def update(def auth, def program, ApiMergeMode mergeMode = ApiMergeMode.MERGE,
               ApiStrategy apiStrategy = ApiStrategy.CREATE_AND_UPDATE,
               ApiVersion apiVersion = null) {

        def query = [mergeMode: mergeMode.value(), strategy: apiStrategy.value()]

        // Default mergeMode in 2.24 and prior is "MERGE". Default in 2.25 and higher is "REPLACE"
        def result = apiService.put(auth, PATH, program, program.id, query, ContentType.JSON, apiVersion)

        return result
    }

    /**
     * Finds all Programs with the specified parameters
     *
     * @param auth DHIS 2 Credentials
     * @param queryParams Map of query paramaters to use
     * @param apiVersion ApiVersion to use
     * @return All programs found matching the supplied criteria
     */
    def findAll(def auth, def queryParams = [fields : ":all"],
                ApiVersion apiVersion = null) {

        def programs = apiService.get(auth, "${PATH}", queryParams, null, apiVersion)?.data

        return programs
    }

    /**
     * Retrieves a program with the specified id
     *
     * @param auth DHIS 2 Credentials
     * @param programId The id of the program to retrieve
     * @param query Map of query parameters
     * @param apiVersion ApiVersion to use
     * @return The found program if any
     */
    def get(def auth, def programId, def query=[:], ApiVersion apiVersion = null) {

        def program = apiService.get(auth, "${PATH}/${programId}", query, null, apiVersion)?.data

        log.debug "program: " + program

        return program
    }
}
