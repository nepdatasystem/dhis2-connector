package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional
import groovyx.net.http.ContentType
import org.apache.http.HttpStatus

/**
 * Service to kick off jobs related to resource tables and analytics in the DHIS 2 API
 */
@Transactional
class ResourceTableService {

    final def PATH = "/resourceTables"
    final def ANALYTICS_SUBPATH = "analytics"

    final String RESOURCE_TABLE_SUCCESS_MESSAGE = "Initiated resource table update"
    final String ANALYTICS_TABLE_SUCCESS_MESSAGE = "Initiated analytics table update"

    def apiService

    /**
     * Generates DHIS 2 resource tables
     * Within DHIS 2, the resource tables are also refreshed when generating the analytics tables, so no need to call
     * this one directly if calling the generateAnalyticsTables
     *
     * @param auth DHIS 2 Credentials
     * @param apiVersion ApiVersion to use
     * @return The parsed Result object from the creation
     */
    def generateResourceTables (def auth, ApiVersion apiVersion = null) {

        def result = apiService.post(auth, PATH, [], [:], ContentType.JSON, apiVersion)

        // TODO: this response is non-standard. We only know it was successful when the Http Status = 200 and
        // the message = "Initiated resource table update"
        // Need to update the response success to reflect this, until this response is changed in DHIS 2
        log.debug "generateResourceTables Response: " + result

        if (result?.status == HttpStatus.SC_OK && result?.message == RESOURCE_TABLE_SUCCESS_MESSAGE) {
            result?.success = true
        }

        return result
    }

    /**
     * Generates the analytics tables
     * This also regenerates the resource tables too
     *
     * @param auth DHIS 2 Credentials
     * @param apiVersion ApiVersion to use
     * @return The parsed Result object from the creation
     */
    def generateAnalyticsTables (def auth, ApiVersion apiVersion = null) {

        def result = apiService.post(auth, "${PATH}/${ANALYTICS_SUBPATH}", [], [:], ContentType.JSON, apiVersion)

        // TODO: this response is non-standard. We only know it was successful when the Http Status = 200 and
        // the message = "Initiated analytics table update"
        // Need to update the response success to reflect this, until this response is changed in DHIS 2
        log.debug "generateAnalyticsTables Response: " + result

        if (result?.status == HttpStatus.SC_OK && result?.message == ANALYTICS_TABLE_SUCCESS_MESSAGE) {
            result?.success = true
        }

        return result
    }

}
