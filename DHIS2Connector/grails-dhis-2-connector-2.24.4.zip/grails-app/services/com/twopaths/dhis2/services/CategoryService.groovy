package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional
import groovyx.net.http.ContentType

/**
 * Service to do Category CRUD with the DHIS 2 API
 */
@Transactional
class CategoryService {

    final def PATH = "/categories"
    final def CATEGORY_OPTIONS_SUB_PATH = "categoryOptions"

    def apiService

    /**
     * Retrieves the specified Category from the DHIS 2 API
     *
     * @param auth DHIS 2 Credentials
     * @param id Id of the CategoryCombo to retrieve
     * @param fields Fields requested in the response from the API
     * @param apiVersion ApiVersion to use
     * @return The Category found if any
     */
    def get(def auth, def id, ArrayList<String> fields = [],
            ApiVersion apiVersion = null) {

        def queryParams = [:]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def category = apiService.get(auth, "${PATH}/${id}", queryParams, null,
                apiVersion)?.data

        log.debug "category: " + category

        return category
    }

    /**
     * Finds all Categories with the specified name
     *
     * @param auth DHIS 2 Credentials
     * @param name The name to retrieve Categories for
     * @param fields Fields requested in the response from the API
     * @param apiVersion ApiVersion to use
     * @return The Category found if any
     */
    def findByName(def auth, def name, ArrayList<String> fields = [],
                   ApiVersion apiVersion = null) {

        def queryParams = [filter: "name:eq:${name}"]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def categories = apiService.get(auth, "${PATH}", queryParams, null, apiVersion)?.data?.categories

        log.debug "categories: " + categories

        def categoryOption
        if (categories.size() == 1) {
            categoryOption = categories[0]
        }

        log.debug "categoryOption: " + categoryOption

        return categoryOption
    }

    /**
     * Finds all Categories in the system
     *
     * @param auth DHIS 2 Credentials
     * @param fields Fields requested in the response from the API
     * @param apiVersion ApiVersion to use
     * @return The full list of Categories
     */
    def findAll(def auth, ArrayList<String> fields = [], ApiVersion apiVersion = null) {

        def queryParams = [:]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def categories = apiService.get(auth, "${PATH}", queryParams, null, apiVersion)?.data

        log.debug "categories: " + categories

        return categories
    }

    /**
     * Creates a Category
     *
     * @param auth DHIS 2 Credentials
     * @param category The category object to create
     * @param apiVersion ApiVersion to use
     * @return The parsed Result object from the creation
     */
    def create(def auth, def category, ApiVersion apiVersion = null) {

        log.debug ">>> create category: " + category

        // remove the id
        category.remove('id')

        def result = apiService.post(auth, PATH, category, [:], ContentType.JSON, apiVersion)

        log.debug "<<< create category, result: " + result

        return result
    }

    /**
     * Assigns the specified CategoryOption to the specified Category
     *
     * @param auth DHIS 2 Credentials
     * @param categoryId The Id of the Category to assign the CategoryOption to
     * @param categoryOptionId The Id of the CategoryOption to assign to the Category
     * @param apiVersion ApiVersion to use
     * @return The parsed Result object from the API
     */
    def assignCategoryOptionToCategory(def auth, def categoryId, def categoryOptionId,
                                       ApiVersion apiVersion = null) {

        log.debug ">>> categoryId: " + categoryId

        def json = apiService.post(auth, "${PATH}/${categoryId}/${CATEGORY_OPTIONS_SUB_PATH}/${categoryOptionId}",
                null, [:], ContentType.JSON, apiVersion )

        return json
    }

}
