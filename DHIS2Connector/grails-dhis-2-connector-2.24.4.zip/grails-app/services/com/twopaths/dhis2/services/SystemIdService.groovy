package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional

/**
 * Service to interact with DHIS 2 API system ids
 */
@Transactional
class SystemIdService {

    final def PATH = "/system/id"


    def apiService

    /**
     * Generates unique system ids (UIDs) via the DHIS 2 API
     * @param auth DHIS 2 Credentials
     * @param numIds Number of system ids to generate
     * @param apiVersion ApiVersion to use
     * @return List of system ids
     */
    def getIds(def auth, def numIds=1, ApiVersion apiVersion = null) {

        def query = [limit:numIds]

        def ids = apiService.get(auth, PATH, query, null, apiVersion).data['codes']

        log.debug "ids: " + ids

        return ids
    }
}
