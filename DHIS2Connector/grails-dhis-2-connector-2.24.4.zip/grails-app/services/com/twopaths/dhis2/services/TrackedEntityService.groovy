package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional

/**
 * Service to do TrackedEntity CRUD with the DHIS 2 API
 */
@Transactional
class TrackedEntityService {

    final def PATH = "/trackedEntities"
    
    def apiService

    /**
     * Finds all TrackedEntities in the system
     *
     * @param auth DHIS 2 Credentials
     * @param fields Fields requested in the response from the API
     * @param apiVersion ApiVersion to use
     * @return A full list of trackedEntities
     */
    def findAll(def auth, ArrayList<String> fields = [":all"],
                ApiVersion apiVersion = null) {

        def queryParams = [:]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def trackedEntities = apiService.get(auth, "${PATH}", queryParams, null, apiVersion)?.data

        return trackedEntities
    }
}
