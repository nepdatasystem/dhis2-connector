package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional

/**
 * Service to do User CRUD with the DHIS 2 API
 */
@Transactional
class UserService {
    
    final def PATH_CURRENT_USER = "/me"
    final def USER_CREDENTIALS_ROLES_FIELDS = "userCredentials[userRoles[name]]"

    def apiService

    /**
     * Find the roles for the supplied username
     *
     * @param auth DHIS 2 Credentials
     * @param apiVersion ApiVersion to use
     * @return UserRoles associated with the associated user credentials
     */
    def findUserRoles(def auth, ApiVersion apiVersion = null) {

        def queryParams = [fields: USER_CREDENTIALS_ROLES_FIELDS]

        // has not been implemented in DHIS 2 core. Have contacted DHIS 2 developers to fix.
        def userCredentials = apiService.get(auth, "${PATH_CURRENT_USER}", queryParams, null,
                apiVersion)?.data
        
        log.debug "userCredentials: " + userCredentials
        
        def userRoles

        if (userCredentials?.userCredentials?.userRoles) {
        
            userRoles = userCredentials.userCredentials.userRoles?.collect { userRole -> userRole.name }
        }
        log.debug "userRoles: " + userRoles

        return userRoles
    }
}
