package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional
import groovyx.net.http.ContentType

/**
 * Service to do TrackedEntityInstance CRUD with the DHIS 2 API
 */
@Transactional
class TrackedEntityInstanceService {

    final def PATH = "/trackedEntityInstances"
    
    def apiService

    /**
     * Creates a trackedEntityInstance
     *
     * @param auth DHIS 2 Credentials
     * @param trackedEntityInstance the trackedEntityInstance to create
     * @param query Map of query paramaters to use
     * @param apiVersion ApiVersion to use
     * @return The parsed Result object from the creation
     */
    def create(def auth, def trackedEntityInstance, def query=[:],
               ApiVersion apiVersion = null) {

        def result = apiService.post(auth, PATH, trackedEntityInstance, query, ContentType.JSON, apiVersion)

        log.debug "create, result: " + result

        return result
    }

    /**
     * Updates a trackedEntityInstance
     *
     * @param auth DHIS 2 Credentials
     * @param trackedEntityInstance The trackedEntityInstance to update
     * @param trackedEntityInstanceId The id of the trackedEntityInstance to update
     * @param query Map of query paramaters to use
     * @param apiVersion ApiVersion to use
     * @return The parsed Result object from the update
     */
    def update(def auth, def trackedEntityInstance, def trackedEntityInstanceId, def query=null,
               ApiVersion apiVersion = null) {

        def result = apiService.put(auth, PATH, trackedEntityInstance, trackedEntityInstanceId, query,
                ContentType.JSON, apiVersion)

        log.debug "update, result: " + result

        return result
    }

    /**
     * Retrieves a trackedEntityInstance by the specified code
     *
     * @param auth DHIS 2 Credentials
     * @param code The code of the trackedEntityInstance to get
     * @param fields array of fields to return from the API
     * @param apiVersion ApiVersion to use
     * @return The trackedEntityInstance found if any
     */
    def get(def auth, def code, ArrayList<String> fields = [], ApiVersion apiVersion = null) {

        def queryParams = [:]

        if (code) {
            queryParams.put("filter", "code:eq:${code}")
        }

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        log.debug "get, code: " + code

        def trackedEntityInstance = apiService.get(auth, "${PATH}", queryParams, null, apiVersion)?.data

        log.debug "trackedEntityInstance: " + trackedEntityInstance

        return trackedEntityInstance
    }

    /**
     * Retrieves all trackedEntityInstances matching the supplied query parameters
     *
     * @param auth DHIS 2 Credentials
     * @param query Map of query paramaters to use
     * @param apiVersion ApiVersion to use
     * @return List of trackedEntityInstances found
     */
    def findByQuery(def auth, def query=[:], ApiVersion apiVersion = null) {
        
            def trackedEntities = apiService.get(auth, "${PATH}", query, null, apiVersion)?.data
            
            return trackedEntities
    }

    /**
     * Retrieves the id of a trackedEntityInstance by organisationUnit, attribute, and value
     *
     * @param auth DHIS 2 Credentials
     * @param orgUnit The organisationUnit to find the trackedEntityInstance for
     * @param attribute The attribute to find the trackedEntityInstance for
     * @param value The falue to find the trackedEntityInstance for
     * @param apiVersion ApiVersion to use
     * @return The id of the found trackedEntityInstance if any
     */
    def getIdByOrgUnitAttributeAndValue(def auth, def orgUnit, def attribute, def value,
                                        ApiVersion apiVersion = null) {
        
        log.debug "getIdByOrgUnitAttributeAndValue, orgUnit: ${orgUnit}, attribute: ${attribute}, value: ${value}"

        def id

        def queryParams = [ou:orgUnit, filter: "${attribute}:eq:${value}"]
        
        def trackedEntityInstances = apiService.get(auth, "${PATH}", queryParams, null, apiVersion)?.data

        if (trackedEntityInstances?.trackedEntityInstances) {
            if (trackedEntityInstances?.trackedEntityInstances?.size() == 1) {
                id =  trackedEntityInstances.trackedEntityInstances[0].trackedEntityInstance
            } else if (trackedEntityInstances?.trackedEntityInstances?.size() == 0) {
                log.error "No rows for orgUnit: " + orgUnit + " and attribute: " + attribute
            } else {
                log.error "Multiple rows for orgUnit: " + orgUnit + " and attribute: " + attribute
            }
        }
        
        log.debug "trackedEntityInstance id: " + id
        
        // Return the id
        return id
    }

    /**
     * Creates a lookup map of TrackedEntityInstances by the TrackedEntityInstance's code
     *
     * @param auth DHIS 2 Credentials
     * @param fields array of fields to return from the API
     * @param apiVersion ApiVersion to use
     * @return a lookup map of TrackedEntityInstances by the TrackedEntityInstance's code
     */
    def getLookup(def auth, ArrayList<String> fields = [":all"],
                  ApiVersion apiVersion = null) {

        def queryParams = [:]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def lookup = [:]
        
        def allTrackedEntityInstances = []
        
        def trackedEntityInstances = apiService.get(auth, "${PATH}", queryParams, null, apiVersion)?.data
        
        allTrackedEntityInstances.addAll(trackedEntityInstances.trackedEntityInstances)
        
        // Create the lookup from the tracked entity attributes
        allTrackedEntityInstances.each { trackedEntityInstance ->
            lookup << [("${trackedEntityInstance.code}".toString()): trackedEntityInstance]
        }
        
        return lookup
    }
}
