package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional
import groovyx.net.http.ContentType

/**
 *
 * Service to do DataValue CRUD with the DHIS 2 API
 */
@Transactional
class DataValueService {

    final def PATH = "/dataValueSets"

    def apiService

    /**
     * Creates a data value via the API
     *
     * @param auth DHIS 2 Credentials
     * @param dataValue The Data Value to create
     * @param apiVersion ApiVersion to use
     * @return the Result of the data value creation
     */
    def create(def auth, def dataValue, ApiVersion apiVersion = null) {

        def result = apiService.post(auth, PATH, dataValue, [:], ContentType.JSON, apiVersion)

        log.debug "<<< dataValue: " + dataValue

        return result

    }

    /**
     * Retrieves data values matching the supplied criteria
     *
     * @param auth DHIS 2 Credentials
     * @param dataSetId Id of the data set to retrieve data values for
     * @param orgUnitId Id of the org unit to retrieve data values for
     * @param limit Max number of records to retrieve
     * @param startDate Min date to retrieve data values for
     * @param endDate Max date to retrieve data values for
     * @param children Whether or not to include children in the records retrieved
     * @param apiVersion ApiVersion to use
     * @return dataValues found
     */
    def read (def auth, def dataSetId, def orgUnitId, def limit = null,
              def startDate = "1970-01-01", def endDate="2100-01-01", def children = true,
              ApiVersion apiVersion = null) {

        def queryParams = [
                dataSet: dataSetId,
                orgUnit: orgUnitId,
                startDate: startDate,
                endDate: endDate,
                children: children
        ]

        if (limit && limit > 0) {
            queryParams.put("limit", limit)
        }

        def response = apiService.get(auth, PATH, queryParams, null, apiVersion)?.data

        def dataValues = response?.dataValues

        return dataValues
    }
}
