package com.twopaths.dhis2.api

/**
 * Created by lcrees on 2016-08-22.
 */
enum ApiActionType {

    Import ("import"),
    Update ("update"),
    Get ("get"),
    Delete ("delete")

    private String name

    private ApiActionType(String name) {
        this.name = name
    }

    public String value() {
        name
    }

    String toString() {
        name
    }

}