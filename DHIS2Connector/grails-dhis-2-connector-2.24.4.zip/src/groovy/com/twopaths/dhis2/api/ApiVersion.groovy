package com.twopaths.dhis2.api

/**
 * Which version of the DHIS 2 API should be used
 */
enum ApiVersion {

    /*
    * The Default version of the API (no version number supplied). Will eventually be the current
    * version of DHIS 2 being used as API versioning is gradually introduced.
    */
    DHIS2_DEFAULT_VERSION ("default", ""),

    /* Version 2.23 of the API. As of 2.23, this is only used for the /api/metadata API call */
    DHIS2_VERSION_223 ("2.23", "/23"),

    /* Version 2.24 of the API. As of 2.24, the majority of the API has been versioned. See comments
     * in ApiResultParser224Service.groovy */
    DHIS2_VERSION_224 ("2.24", "/24")


    private static Map<String, ApiVersion> lookup = new HashMap<String, ApiVersion>()

    static {
        for (ApiVersion apiVersion : ApiVersion.values()) {
            lookup.put(apiVersion.value(), apiVersion);
        }
    }

    private String name

    private String apiVersionSubPath

    private ApiVersion (String name, String apiVersionSubPath) {
        this.name = name
        this.apiVersionSubPath = apiVersionSubPath
    }

    public String value() {
        name
    }

    public String getApiVersionSubPath () {
        apiVersionSubPath
    }

    public static ApiVersion get(String name) {
        return lookup.get(name);
    }
}