package com.twopaths.dhis2.api

/**
 * Defines parse method for parsing DHIS 2 API Results based off of DHIS 2 API version
 */
interface ApiResultParser {

    // Need to explicitly list these two method signatures to allow for a default parameter value in the implementing class
    // EG: implementation will be:
    // Result parse(ApiActionType action, def data, def status, def requestBody = null) { ... }
    Result parse(ApiActionType action, def data, def status);
    Result parse(ApiActionType action, def data, def status, def requestBody);

}