package com.twopaths.dhis2.api

/**
 * The Type of response from the DHIS 2 API
 */
enum ApiResponseType {

    /*
     * An Object Report is returned from the API for individual instantiated objects
     * (eg: Program instances, Data Element instances, etc)
     */
    ObjectReport ("ObjectReport", "objectReports"),

    /*
     * A Type Report is returned from the API for metadata objects
     */
    TypeReport ("TypeReport", "typeReports")

    private String name

    private String pluralizedName

    private ApiResponseType (String name, String pluralizedName) {
        this.name = name
        this.pluralizedName = pluralizedName
    }

    public String value() {
        name
    }

    public String getPluralizedName() {
        pluralizedName
    }

}