package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiStrategy
import com.twopaths.dhis2.api.ApiVersion
import com.twopaths.dhis2.api.Result
import groovyx.net.http.ContentType

class EventService {

    final def PATH = "/events"
    
    def apiService

    def create(def auth, def event, def query = [:], ApiVersion apiVersion = null) {

        def result = apiService.post(auth, PATH, event, query, ContentType.JSON, apiVersion)

        log.debug "create, result: ${result}"

        return result
    }

    // TODO: Fix when the response changes
    def update(def auth, def event, def eventId, def query = [:],
               ApiVersion apiVersion = null) {

        def result = apiService.put(auth, PATH, event, eventId, query, ContentType.JSON, apiVersion)

        def message = result?.message

        // TODO: Hack to cater for the fact that a 'response' is not returned so we just check for the content of the message field and construct fake data
        if (message?.startsWith("Import was successful.")) {
            result.importCount?.updated = 1
            result.succeeded = 1
            result.success = true

        } else {

            result.importCount?.ignored = 1
        }

        return result
    }

    def findByQuery(def auth, def query, ApiVersion apiVersion = null) {

        def events = apiService.get(auth, PATH, query, null, apiVersion)?.data

        log.debug "findByQuery, events: ${events}"

        return events
    }

    def findByProgramStageIdAndTrackedEntityInstanceId(def auth, def programStageId, def trackedEntityInstanceId,
                                                       ApiVersion apiVersion = null) {

        def queryParams = [programStage: programStageId, trackedEntityInstance: trackedEntityInstanceId]
        def event = apiService.get(auth, PATH, queryParams, null, apiVersion)?.data

        log.debug "findByProgramStageIdAndTrackedEntityInstanceId, event: ${event}"

        return event
    }

    def get(def auth, def code, ArrayList<String> fields = [],
            ApiVersion apiVersion = null) {

        def queryParams = [:]

        if (code) {
            queryParams.put("filter", "code:eq:${code}")
        }

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def event = apiService.get(auth, "${PATH}", queryParams, null,
                apiVersion)?.data

        log.debug "get, event: ${event}"

        return event
    }
}
