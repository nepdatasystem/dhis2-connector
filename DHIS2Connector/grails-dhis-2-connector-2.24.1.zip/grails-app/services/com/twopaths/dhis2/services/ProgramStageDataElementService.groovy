package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiStrategy
import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional
import groovyx.net.http.ContentType

@Transactional
class ProgramStageDataElementService {

    final def PATH = "/programStageDataElements"
    
    def apiService
    
    def create(def auth, def programStageDataElement, ApiVersion apiVersion = null) {
        
        log.debug "programStageDataElement.create"

        def result = apiService.post(auth, PATH, programStageDataElement, [:], ContentType.JSON, apiVersion)
        
        log.debug "programStage: " + result
        
        return result
    }
    
    def update(def auth, def programStageDataElement, ApiStrategy apiStrategy = ApiStrategy.CREATE_AND_UPDATE,
               ApiVersion apiVersion = null) {

        def query = [strategy: apiStrategy.value()]

        log.debug "programStageDataElement.update"

        def result = apiService.put(auth, PATH, programStageDataElement, programStageDataElement.id, query,
                ContentType.JSON, apiVersion)

        return result
    }
    
    def findAll(def auth, ArrayList<String> fields = [":all"],
                ApiVersion apiVersion = null) {

        def queryParams = [:]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        log.debug "programStageDataElements.findAll"

        def programStageDataElements = apiService.get(auth, "${PATH}", queryParams, null, apiVersion)?.data

        return programStageDataElements
    }
}
