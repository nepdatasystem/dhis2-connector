package com.twopaths.api

import com.twopaths.dhis2.api.ApiResultParser
import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional

@Transactional
class ApiResultParserFactoryService {

    def apiResultParser223Service
    def apiResultParser224Service
    def apiResultParserDefaultService

    ApiResultParser getParser(ApiVersion apiVersion) {

        switch (apiVersion) {
            case ApiVersion.DHIS2_VERSION_223 :
                return apiResultParser223Service;
                break;
            case ApiVersion.DHIS2_VERSION_224 :
                return apiResultParser224Service;
                break;
            case ApiVersion.DHIS2_DEFAULT_VERSION :
                return apiResultParserDefaultService
                break;

        }
    }
}
