package com.twopaths.dhis2.api

import groovy.util.logging.Log4j

@Log4j
class Result {
    
    def data
    def conflicts = []
    def importCount
    def errors = []
    def lastImported
    def reference
    def succeeded = 0
    def status
    def success = false
    def message

    final int MESSAGE_CHAR_LENGTH = 500

    def Result() {
    }
    
    def Result(def action, def data, def status) {

        // Some API calls return text instead of JSON...which is a bug...and can probably be removed at some stage...
        if (status == 500) {
            this.success = false
            this.errors << [code: "dhis2.error", args: [action, "DHIS 2 Internal Server Error"]]
        }
        else if (data instanceof StringReader) {
            this.data = data?.text
        } else {
            if (data?.response) { // JSON response
                def importSummary
                // Only interested in conflicts if import, update or delete
                if (action != "get") {
                    // New response data
                    if (data?.response?.size()) {
                        log.debug "data.response.conflicts: ${data.response.conflicts}"
                        importSummary = data.response

                        // If responseType == importSummaries, get the importSummary
                        if (data.response?.responseType == "ImportSummaries") {
                            importSummary = data.response?.importSummaries?.get(0)
                        }
                        if (importSummary?.conflicts != null) {
                            this.conflicts = importSummary.conflicts
                        } else if (importSummary?.importConflicts != null) {
                            this.conflicts = importSummary.importConflicts
                        }
                        this.importCount = importSummary.importCount
                    }
                }

                // Check importSummary for error status
                if (importSummary?.status == "ERROR") {
                    this.errors << [code: "dhis2.error", args: [action, importSummary.description]]
                }

                // Check importSummary for warning status
                if (importSummary?.status == "WARNING") {
                    this.errors << [code: "dhis2.error", args: [action, importSummary.description]]
                }
                
                // lastImported
                if (action == "import" || action == "update") {
                    // for data values there is no response key but also no last imported
                    lastImported = importSummary?.lastImported
                    reference = importSummary?.reference
                }
            } else { // Old non response data. Data Value import is like this.
                log.debug "data.conflicts: ${data?.conflicts}"
                if (data?.conflicts != null) {
                    this.conflicts = data.conflicts
                } else if (data?.importConflicts != null) {
                    this.conflicts = data.importConflicts
                }
                this.importCount = data?.importCount
            }

            // HTTP status
            this.status = status

            // Iterate through the import conflicts and get the errors
            this.conflicts?.each { conflict ->
                println "conflict: " + conflict
                this.errors << [code: "dhis2.error", args: [conflict."object", conflict?.value]]
            }


            // import/update/delete count of success/failures
            if (action == "import" || action == "update" || action == "delete") {
                switch (action) {
                    // Some POSTs allow update so need to check the imported and updated count...
                    case "import":
                    this.succeeded = (this?.importCount?.imported?:0) + (this?.importCount?.updated?:0)
                    break
                    case "update":
                    this.succeeded = this?.importCount?.updated?:0
                    break
                    case "delete":
                    this.succeeded = this?.importCount?.deleted?:0
                    break
                }
            }

            // 204 = no body but OK
            if (status == 204) {
                this.success = true
            } else {
                // Success...
                this.success = succeeded != 0 && this.errors.size() == 0 && this.conflicts.size() == 0
            }

            // Set message too
            this.message = data?.message
        }

        // If doing a get, then set the data
        if (action == "get") {
            if (data) {
                this.data = data
                this.success = true
            } else {
                this.success = false
            }
        }
    }

    static Result create() {
        return new Result()
    }
    
    Result setErrors(def errors) {
        this.errors = errors
        return this
    }
    
    Result setSuccess(def success) {
        this.success = success
        return this
    }
    
    public String toString() {
        return new StringBuilder()
            .append("Result: [")
            .append("data: ").append(data?.take(MESSAGE_CHAR_LENGTH)).append(", ")
            .append("errors: ").append(errors).append(", ")
            .append("conflicts: ").append(conflicts).append(", ")
            .append("importCount: ").append(importCount).append(", ")
            .append("lastImported: ").append(lastImported).append(", ")
            .append("reference: ").append(reference).append(", ")
            .append("succeeded: ").append(succeeded).append(", ")
            .append("status: ").append(status).append(", ")
            .append("success: ").append(success).append(", ")
            .append("message: ").append(message)
            .append("]").toString()
    }
}
