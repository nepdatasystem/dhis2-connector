package com.twopaths.api

import com.twopaths.dhis2.api.Result
import grails.transaction.Transactional
import groovy.json.JsonBuilder
import groovyx.net.http.ContentType
import groovyx.net.http.RESTClient

@Transactional
class ApiService {
    
    def server
    def context

    // POST
    def post(def auth, def path, def body=[], def query=[:], def contentType = ContentType.JSON) {

        log.debug "post, path: " + path + ", body: " + new JsonBuilder(body).toString() + ", query: " + query
        
        RESTClient http = getRestClient(auth)

        def response

        // Failure handler...get the response anyway
        http.handler.failure = { resp, json ->
            log.error "Unexpected failure: ${resp.statusLine}, resp: ${resp}, json: ${json}"
            resp.setData(json)
            return resp
        }

        // POST the request and get the response
        try {
            response = http.post(path: context + path, body: new JsonBuilder(body).toString(), query: query, contentType: contentType, requestContentType: ContentType.JSON)
        } catch (Exception e) {
            log.error "Exception: " + e
        }
        
        if (response?.status in [200]) {
            log.debug "put, OK response?.status: ${response?.status}"
       }
        
        if (response?.status in [409]) {
            log.debug "put, conflict response?.status: ${response?.status}"
       }
        
        return  new Result("import", response?.data, response?.status)
    }
    
    // PUT
    def put(def auth, def path, def body, def id, def query=[:], def contentType = ContentType.JSON) {
        
        path = context + path + "/" + id
        body.remove("user");
        
        log.debug "put, path: " + path
        log.debug "put, body: " + new JsonBuilder(body).toString()
        log.debug "put, id: " + id
        log.debug "put, query: " + query
        
        RESTClient http = getRestClient(auth)

        def response

        // Failure handler....get the response from the json
        http.handler.failure = { resp, json ->
            log.error "Unexpected failure: ${resp.statusLine}, resp: ${resp}, json: ${json}"
            resp.setData(json)
            return resp
        }

        // PUT the request and get the response
        try {
            response = http.put(path: path, body: new JsonBuilder(body).toString(), query: query, contentType: contentType, requestContentType: ContentType.JSON)
        } catch (Exception e) {
            log.error "Exception: " + e
        }
        log.debug "put, response?.status: " + response?.status

        if (response?.status in [200, 201, 202]) {
             log.debug "put, OK response?.status: ${response?.status}"   
        }
        
        if (response?.status in [409]) {
            log.debug "put, conflict response?.status: ${response?.status}"
        }
        
        return new Result("update", response?.data, response?.status)
    }


    // GET
    def get(def auth, def path, def query=[:], def queryString=null) {

        query << [preheatCache:false]
        
        if (query.paging) {
            query << [paging: query.paging]
        } else {
            query << [paging: false]
        }
        log.debug "get, path: " + path + ", query: " + query
        
        RESTClient http = getRestClient(auth)

        http.handler.failure = { resp ->
            log.debug "Error: " + resp.statusLine.statusCode
        }
        
        http.handler."404" = { resp ->
            log.debug "404: " + resp
        }
        
        def response
        try {
            response = http.get(path: context + path, contentType: ContentType.JSON, query: query, queryString: queryString)
        } catch (Exception e) {
            log.error "Exception: " + e
        }
        log.debug "response?.status: " + response?.status

        if (response?.status in [200]) {
            log.debug "response?.status: ${response?.status}"
       }
        
        return new Result("get", response?.data, response?.status)
    }
    

    /**
     * Get REST Client using authentiation from logged in user
     * 
     * @return RESTClient
     */
    private def getRestClient(auth) {
        def username
        def password
        
        if (auth) {
            username = auth.username
            password = auth.password
        } else { 
            log.error("No authentication details provided, cannot authenticate")
        }
        
        def http = new RESTClient(server)
        
        http.headers['Authorization'] = 'Basic ' + "${username}:${password}".getBytes().encodeBase64()

        return http
    }
}
