package com.twopaths.dhis2.services

import grails.transaction.Transactional

@Transactional
class DataSetService {

    def PATH = "/api/dataSets"

    def apiService
    def messageSource
    def sqlViewService
    def propertiesService

    public def FIELD_ID = "id"
    public def FIELD_NAME = "name"
    public def FIELD_SHORT_NAME = "shortName"
    public def FIELD_USER = "user"
    public def FIELD_CREATED = "created"
    public def FIELD_LAST_UPDATED = "lastUpdated"
    public def FIELD_DATA_ELEMENTS = "dataElements"
    public def FIELD_DATA_ELEMENTS_CATEGORY_COMBO = "[id,categoryCombo[name,categoryOptionCombos::isNotEmpty]"

    def create(def auth, def dataSet) {

        log.debug ">>> dataSet: " + dataSet

        def result = apiService.post(auth, PATH, dataSet)

        log.debug "<<< dataSet, result: " + result

        return result
    }

    def findAll(def auth, ArrayList<String> fields = []) {
        def queryParams = [:]
        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def dataSets = apiService.get(auth, PATH, queryParams)?.data?.dataSets

        log.debug "<<< dataSets: " + dataSets

        return dataSets
    }

    def findAllWithReuploadInfo(def auth) {
        def dataSetFields = [
                FIELD_ID,
                FIELD_NAME,
                FIELD_SHORT_NAME,
                FIELD_USER,
                FIELD_CREATED,
                FIELD_LAST_UPDATED,
                FIELD_DATA_ELEMENTS + FIELD_DATA_ELEMENTS_CATEGORY_COMBO
        ]
        def dataSets = findAll(auth, dataSetFields)
        def dataSetsWithData = findDataSetsWithData(auth)?.flatten()
        dataSets.each { dataSet ->
            dataSet.hasMetadata = dataSet.dataElements?.size() > 0
            dataSet.hasDisaggregations = false
            if (dataSet.hasMetadata) {
                dataSet.dataElements.find { dataElement ->
                    if (dataElement.categoryCombo?.name != "default") {
                        dataSet.hasDisaggregations = dataElement.categoryCombo?.categoryOptionCombos
                        return true
                    }
                }
            }
            dataSet.hasData = dataSet.id in dataSetsWithData
        }
        return dataSets
    }

    def findDataSetsWithData (def auth) {

        def sqlViewName = propertiesService.getProperties().getProperty('nep.sqlview.datasets.with.data.name', null)

        if (!sqlViewName) {
            throw new Exception("No application property specified for 'nep.sqlview.datasets.with.data.name'. " +
                    "Please create this property and create corresponding view in DHIS 2, then restart the application")
        }
        def sqlView = sqlViewService.findByName(auth, sqlViewName)
        if (!sqlView) {
            throw new Exception("Unable to find sql view with name ${sqlViewName}. Please ensure this has been created in DHIS 2")
        }
        // need to execute the view first in case the actual underlying db view was deleted
        sqlViewService.executeView(auth, sqlView.id)
        return sqlViewService.getViewData(auth, sqlView.id)
    }

    def get(def auth, def id) {

        def dataSet = apiService.get(auth, "${PATH}/${id}")?.data

        log.debug "dataSet: " + dataSet

        return dataSet
    }

    def getFrequencies() {

        return [
                Daily : messageSource.getMessage("dataset.frequency.Daily", null, Locale.default),
                Weekly : messageSource.getMessage("dataset.frequency.Weekly", null, Locale.default),
                Monthly : messageSource.getMessage("dataset.frequency.Monthly", null, Locale.default),
                BiMonthly : messageSource.getMessage("dataset.frequency.BiMonthly", null, Locale.default),
                Quarterly : messageSource.getMessage("dataset.frequency.Quarterly", null, Locale.default),
                SixMonthly : messageSource.getMessage("dataset.frequency.SixMonthly", null, Locale.default),
                SixMonthlyApril : messageSource.getMessage("dataset.frequency.SixMonthlyApril", null, Locale.default),
                Yearly : messageSource.getMessage("dataset.frequency.Yearly", null, Locale.default),
                FinancialApril : messageSource.getMessage("dataset.frequency.FinancialApril", null, Locale.default),
                FinancialJuly : messageSource.getMessage("dataset.frequency.FinancialJuly", null, Locale.default),
                FinancialOct : messageSource.getMessage("dataset.frequency.FinancialOct", null, Locale.default)
        ]
    }

    def getOpenFuturePeriods() {

        return [
                "0" : messageSource.getMessage("label.no", null, Locale.default),
                "12" : messageSource.getMessage("label.yes", null, Locale.default)
        ]
    }
}
