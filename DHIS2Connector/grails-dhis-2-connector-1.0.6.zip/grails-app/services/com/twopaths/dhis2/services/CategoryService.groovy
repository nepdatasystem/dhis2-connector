package com.twopaths.dhis2.services

import grails.transaction.Transactional

@Transactional
class CategoryService {
    def PATH = "/api/categories"
    def CATEGORY_OPTIONS_SUB_PATH = "categoryOptions"

    def apiService

    def get(def auth, def id) {

        def category = apiService.get(auth, "${PATH}/${id}")?.data

        log.debug "category: " + category

        return category
    }
    def findByName(def auth, def name) {

        def categories = apiService.get(auth, "${PATH}", [filter: "name:eq:${name}"])?.data?.categories

        log.debug "categories: " + categories

        def categoryOption
        if (categories.size() == 1) {
            categoryOption = categories[0]
        }

        log.debug "categoryOption: " + categoryOption

        return categoryOption
    }

    def findAll(def auth) {

        def categories = apiService.get(auth, "${PATH}")?.data

        log.debug "categories: " + categories

        return categories
    }

    def create(def auth, def category) {

        log.debug ">>> create category: " + category

        // remove the id
        category.remove('id')

        def result = apiService.post(auth, PATH, category)

        log.debug "<<< create category, result: " + result

        return result
    }

    def assignCategoryOptionToCategory(def auth, def categoryId, def categoryOptionId) {
        log.debug ">>> categoryId: " + categoryId

        def json = apiService.post(auth, "${PATH}/${categoryId}/${CATEGORY_OPTIONS_SUB_PATH}/${categoryOptionId}")

        return json
    }

}
