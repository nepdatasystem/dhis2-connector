package com.twopaths.dhis2.api

/**
 * Supported merge modes for DHIS 2
 * Note that expected values in API are all uppercase
 */
enum ApiMergeMode {

    MERGE ("MERGE"),
    REPLACE ("REPLACE")


    private String name

    private ApiMergeMode (String name) {
        this.name = name
    }

    public String value() {
        name
    }
}