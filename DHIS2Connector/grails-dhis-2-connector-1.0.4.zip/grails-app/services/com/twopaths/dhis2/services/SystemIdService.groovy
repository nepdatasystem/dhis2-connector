package com.twopaths.dhis2.services

import grails.transaction.Transactional

@Transactional
class SystemIdService {
    
    def PATH = "/api/system/id"


    def apiService

    /**
     * Find the roles for the supplied username
     * 
     * @param auth username/password map
     * param n number of codes to generate
     * 
     * @return List of codes
     */
    def get(def auth, def n=1) {
        def result = apiService.get(auth, PATH, [n:n])
        log.debug "create, result: " + result
        return result
    }
}
