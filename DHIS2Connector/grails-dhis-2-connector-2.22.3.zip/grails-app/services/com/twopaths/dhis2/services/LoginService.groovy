package com.twopaths.dhis2.services

import groovyx.net.http.HTTPBuilder
import groovyx.net.http.HttpResponseDecorator
import org.apache.http.conn.HttpHostConnectException
import org.springframework.security.authentication.AuthenticationServiceException

class LoginService {

    def LOGIN_URL = "/dhis-web-commons-security/login.action"

    def server
    def context
    
    def authenticate(def username, def password) {

        def http = new HTTPBuilder(server)

        def postBody = [authOnly: true, j_username: username, j_password: password] // will be url-encoded

        def json
        def authenticated = false
        
        // Handler for successful login
        http.handler."200" = { HttpResponseDecorator resp, reader ->
            log.debug("Login successful")
            authenticated = true
        }

        // Handler for failed login
        http.handler."302" = { HttpResponseDecorator resp, reader ->
            log.debug "!!! 302 !!!"
            authenticated = false
        }
        
        http.handler.failure = { HttpResponseDecorator resp, reader ->
            log.debug "!!! failure !!!"
            authenticated = false
            def rsp = resp
            def rdr = reader
        }

        try {
            // Attempt to login
            http.post(path: context + LOGIN_URL, body: postBody, requestContentType: groovyx.net.http.ContentType.URLENC) { resp ->
                log.debug "POST Success: ${resp.statusLine}"
                log.debug "resp: " + resp
            }
        } catch (Exception e) {
            log.error ("Unable to post login to DHIS 2", e)
            authenticated = false
            if (e instanceof HttpHostConnectException) {
                throw new AuthenticationDHIS2ConnectionException ("Unable to connect to DHIS 2 to authenticate")
            } else {
                throw new AuthenticationServiceException ("Unspecified authentication error")
            }
        }
        
        log.debug "authenticated: " + authenticated
        return authenticated
    }
}