package com.twopaths.dhis2.services

import grails.transaction.Transactional

@Transactional
class OrganisationUnitService {
    
    def PATH = "/api/organisationUnits"
    
    def apiService

    def getLookup(def auth) {
        
        def lookup = [:]
        
        def allOrganisationUnits = []
        
        // Get the first page of organisation units
        def organisationUnits = apiService.get(auth, "${PATH}")?.data?.organisationUnits

        if (organisationUnits) {
            allOrganisationUnits.addAll(organisationUnits)
        
            // Create the lookup from the organization units 
            allOrganisationUnits.each { organisationUnit ->
                lookup << [("${organisationUnit.code}"?.toString()?.toLowerCase()): organisationUnit.id]
            }
        }
        
        return lookup
    }
    
    def findByLevel(def auth, def level) {
        def orgUnits = apiService.get(auth, "${PATH}", [filter: "level:eq:${level}"])?.data?.organisationUnits
        
        return orgUnits?.collect { orgUnit -> orgUnit.id }
    }

    def findByCode(def auth, def code) {
        def orgUnits = apiService.get(auth, "${PATH}", [filter: "code:eq:${code}"])?.data?.organisationUnits

        def orgUnit
        if (orgUnits.size() == 1) {
            orgUnit = orgUnits[0]
        }
        return orgUnit
    }

    def get(def auth, def id) {
        def orgUnit = apiService.get(auth, "${PATH}/${id}")?.data

        log.debug "orgUnit: " + orgUnit

        return orgUnit
    }

    def update(def auth, def orgUnit) {
        orgUnit = apiService.put(auth, PATH, orgUnit, orgUnit.id)
    }

}
