package com.twopaths.dhis2.services

import grails.transaction.Transactional

@Transactional
class CategoryOptionComboService {

    def PATH = "/api/categoryOptionCombos"
    def CATEGORY_OPTIONS_SUB_PATH = "categoryOptions"

    def apiService
    def get(def auth, def id) {

        def categoryOptionCombo = apiService.get(auth, "${PATH}/${id}")?.data

        log.debug "categoryOptionCombo: " + categoryOptionCombo

        return categoryOptionCombo
    }
    def findByName(def auth, def name) {

        def categoryOptionCombos = apiService.get(auth, "${PATH}", [filter: "name:eq:${name}"])?.data?.categoryOptionCombos

        log.debug "categoryOptionCombos: " + categoryOptionCombos

        def categoryOptionCombo
        if (categoryOptionCombos.size() == 1) {
            categoryOptionCombo = categoryOptionCombos[0]
        }

        log.debug "categoryOptionCombo: " + categoryOptionCombo

        return categoryOptionCombo
    }

    def findAll(def auth) {

        def categoryOptionCombos = apiService.get(auth, "${PATH}")?.data

        log.debug "categoryOptionCombos: " + categoryOptionCombos

        return categoryOptionCombos
    }

    def create(def auth, def categoryOptionCombo) {

        log.debug ">>> create categoryOptionCombo: " + categoryOptionCombo

        // remove the id
        categoryOptionCombo.remove('id')

        def result = apiService.post(auth, PATH, categoryOptionCombo)

        log.debug "<<< create categoryOptionCombo. result: " + result

        return result

    }
    def assignCategoryOptionToCategoryOptionCombo(def auth, def categoryOptionComboId, def categoryOptionId) {
        log.debug ">>> categoryOptionComboId: " + categoryOptionComboId
        log.debug "${PATH}/${categoryOptionComboId}/${CATEGORY_OPTIONS_SUB_PATH}/${categoryOptionId}"

        def json = apiService.post(auth, "${PATH}/${categoryOptionComboId}/${CATEGORY_OPTIONS_SUB_PATH}/${categoryOptionId}")

        return json
    }

}
