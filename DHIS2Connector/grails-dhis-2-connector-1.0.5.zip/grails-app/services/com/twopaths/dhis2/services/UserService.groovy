package com.twopaths.dhis2.services

import grails.transaction.Transactional

@Transactional
class UserService {
    
    def PATH = "/api/users"
    def PATH_CURRENT_USER = "/api/currentUser"
    def PATH_USER_CREDENTIALS ="userCredentials"
    
    def apiService

    /**
     * Find the roles for the supplied username
     * 
     * @param username
     * 
     * @return List of roles
     */
    def findUserRoles(def auth, def username, def password) {
        def user = apiService.get(auth, "${PATH_CURRENT_USER}", [fields: ":all"])?.data
        
        def userCredentials
        if (user) {
            def userId = user.id
            
            userCredentials = apiService.get(auth, "${PATH}/${userId}/${PATH_USER_CREDENTIALS}", [fields: ":all"])?.data
        }
        log.debug "userCredentials: " + userCredentials
        
        def userRoles
        if (userCredentials?.userCredentials?.userRoles) {
        
            userRoles = userCredentials.userCredentials.userRoles?.collect { userRole -> userRole.name }
        }
        log.debug "userRoles: " + userRoles
        return userRoles
    }
}
