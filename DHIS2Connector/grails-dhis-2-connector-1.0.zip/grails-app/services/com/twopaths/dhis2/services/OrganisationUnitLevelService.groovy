package com.twopaths.dhis2.services

import grails.transaction.Transactional

@Transactional
class OrganisationUnitLevelService {

    def PATH = "/api/organisationUnitLevels"

    def apiService

    def getLookup(def auth) {

        def lookup = [:]

        // Get all the organisation units
        def organisationUnitLevels = apiService.get(auth, "${PATH}", [fields: ":all"])?.data?.organisationUnitLevels

        // Create the lookup from the organization unit Levels. Lookup by level to get the name
        organisationUnitLevels.each { organisationUnitLevel ->
            lookup << [("${organisationUnitLevel.level}".toString()): ("${organisationUnitLevel.name}".toString())]
        }

        lookup = lookup.sort {it.key}

        return lookup
    }

    def getByName(def auth, def name) {
        def organisationUnitLevels = apiService.get(auth, "${PATH}", [filter: "name:eq:${name}", fields: ":all"])?.data?.organisationUnitLevels

        def orgUnitLevel
        if (organisationUnitLevels.size() == 1) {
            orgUnitLevel = organisationUnitLevels[0]
        }
        log.debug "orgUnitLevel: " + orgUnitLevel

        return orgUnitLevel
    }
}
