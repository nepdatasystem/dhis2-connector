package com.twopaths.dhis2.services

import grails.transaction.Transactional


@Transactional
class OptionSetService {
    
    def PATH = "/api/optionSets"
    def PATH_OPTIONS = "/options"
    
    def apiService

    def create(def auth, def optionSet) {
        
        def result = apiService.post(auth, PATH, optionSet)
        
        log.debug "create, result: " + result
        
        return result
    }
    
    def addOption(def auth, def optionSetId, def optionValueId) {
        
        log.debug ">>> addOption, optionSetId: " + optionSetId + ", optionValueId: " + optionValueId
        
        def result = apiService.post(auth, PATH + "/" + optionSetId + PATH_OPTIONS + "/" + optionValueId)
        
        log.debug "<<< addOption: " + result
        
        return result
    }
    
    def update(def auth, def optionSet) {
        def result = apiService.put(auth, PATH, optionSet, optionSet.id, [strategy: "CREATE_AND_UPDATE"])
        
        log.debug "update: " + result
        
        return result
    }
    
    def getById(def auth, def id) {
        
        def optionSet = apiService.get(auth, PATH + "/" + id)?.data
        
        log.debug "getById, id: " + id + ", optionSet: " + optionSet
        
        return optionSet
    }
    
    def get(def auth, def name) {
        
        def optionSets = apiService.get(auth, "${PATH}", [filter: "name:eq:${name}"])?.data?.optionSets
        
        log.debug "optionSets: " + optionSets
        
        def optionSet
        if (optionSets.size() == 1) {
            optionSet = optionSets[0]
        }
        
        log.debug "optionSet: " + optionSet
        
        return optionSet
    }
    
    def findByName(def auth, def name) {
        
        def optionSets = apiService.get(auth, "${PATH}", [filter: "name:eq:${name}"])?.data?.optionSets
        
        log.debug "optionSets: " + optionSets
        
        def optionSet
        if (optionSets.size() == 1) {
            optionSet = optionSets[0]
        }
        
        log.debug "optionSet: " + optionSet
        
        return optionSet
    }
    
    def getLookup(def auth) {
        
        def lookup = [:]
        
        def allOptionSets = []
        
        def optionSets = apiService.get(auth, "${PATH}", [fields: ":all"])?.data?.optionSets
        
        if (optionSets) {
            allOptionSets.addAll(optionSets)
        
            // Create the lookup from the option sets
            allOptionSets.each { optionSet ->
                lookup << [("${optionSet.id}".toString()): optionSet]
            }
        }
        return lookup
    }
}
