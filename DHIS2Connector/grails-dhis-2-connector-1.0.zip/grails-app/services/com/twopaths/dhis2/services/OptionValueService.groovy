package com.twopaths.dhis2.services

import grails.transaction.Transactional

@Transactional
class OptionValueService {
    
    def PATH = "/api/options"
    
    def apiService

    def create(def auth, def optionValue) {
        
        log.debug ">>> optionValue: " + optionValue
        
        // remove the id
        optionValue.remove('id')
        
        def result = apiService.post(auth, PATH, optionValue)
        
        log.debug "<<< optionValue, result: " + result
        
        return result
    }
    
    def update(def auth, def optionValue) {
        
        log.debug ">>> optionValue: " + optionValue
        
        def result = apiService.put(auth, PATH, optionValue, optionValue.id)

        log.debug "<<< result: " + result
        
        return result
    }
    
    def get(def auth, def code) {
        
        def optionValue = apiService.get(auth, "${PATH}?code=${code}")?.data
        
        log.debug "optionValue: " + optionValue
        
        return optionValue
    }
}
