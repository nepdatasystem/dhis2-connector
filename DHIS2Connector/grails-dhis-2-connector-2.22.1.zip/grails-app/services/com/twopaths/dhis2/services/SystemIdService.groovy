package com.twopaths.dhis2.services

import grails.transaction.Transactional

@Transactional
class SystemIdService {
    
    def PATH = "/api/system/id"


    def apiService

    /**
     * Find the roles for the supplied username
     * 
     * @param auth username/password map
     * param n number of codes to generate
     * 
     * @return List of codes
     */
    def getIds(def auth, def limit=1) {
        def ids = apiService.get(auth, PATH, [limit:limit]).data['codes']
        log.debug "ids: " + ids
        return ids
    }
}
