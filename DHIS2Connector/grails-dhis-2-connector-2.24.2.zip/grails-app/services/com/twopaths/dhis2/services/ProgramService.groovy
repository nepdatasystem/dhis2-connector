package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiMergeMode
import com.twopaths.dhis2.api.ApiStrategy
import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional
import groovyx.net.http.ContentType

@Transactional
class ProgramService {

    final def PATH = "/programs"

    def apiService

    def create(def auth, def program, ApiVersion apiVersion = null) {

        def created = apiService.post(auth, PATH, program, [:], ContentType.JSON, apiVersion)

        log.debug "program: " + created

        return created
    }

    def update(def auth, def program, ApiMergeMode mergeMode = ApiMergeMode.MERGE,
               ApiStrategy apiStrategy = ApiStrategy.CREATE_AND_UPDATE,
               ApiVersion apiVersion = null) {

        def query = [mergeMode: mergeMode.value(), strategy: apiStrategy.value()]

        // Default mergeMode in 2.24 and prior is "MERGE". Default in 2.25 and higher is "REPLACE"
        def result = apiService.put(auth, PATH, program, program.id, query, ContentType.JSON, apiVersion)

        return result
    }

    def findAll(def auth, def queryParams = [fields : ":all"],
                ApiVersion apiVersion = null) {

        def programs = apiService.get(auth, "${PATH}", queryParams, null, apiVersion)?.data

        return programs
    }

    def get(def auth, def programId, def query=[:], ApiVersion apiVersion = null) {

        def program = apiService.get(auth, "${PATH}/${programId}", query, null, apiVersion)?.data

        log.debug "program: " + program

        return program
    }
}
