package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional

@Transactional
class trackedEntityService {

    final def PATH = "/trackedEntities"
    
    def apiService
    
    def findAll(def auth, ArrayList<String> fields = [":all"],
                ApiVersion apiVersion = null) {

        def queryParams = [:]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def trackedEntities = apiService.get(auth, "${PATH}", queryParams, null, apiVersion)?.data

        return trackedEntities
    }
}
