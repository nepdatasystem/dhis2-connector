package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional

@Transactional
class SystemIdService {

    final def PATH = "/system/id"


    def apiService

    /**
     * Find the roles for the supplied username
     * 
     * @param auth username/password map
     * param n number of codes to generate
     * 
     * @return List of codes
     */
    def getIds(def auth, def limit=1, ApiVersion apiVersion = null) {

        def query = [limit:limit]

        def ids = apiService.get(auth, PATH, query, null, apiVersion).data['codes']

        log.debug "ids: " + ids

        return ids
    }
}
