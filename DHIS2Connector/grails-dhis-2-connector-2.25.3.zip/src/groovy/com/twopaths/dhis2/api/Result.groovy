package com.twopaths.dhis2.api

import groovy.util.logging.Log4j

@Log4j
class Result {

    def data
    def conflicts = []
    def importCount
    def errors = []
    def lastImported
    def reference
    def succeeded = 0
    def status
    def success = false
    def message

    def importTypeSummaries = [:]

    final int MESSAGE_CHAR_LENGTH = 500

    def Result() {
    }

    Result setErrors(def errors) {
        this.errors = errors
        return this
    }
    
    Result setSuccess(def success) {
        this.success = success
        return this
    }
    
    public String toString() {
        return new StringBuilder()
            .append("Result: [")
            .append("data: ").append(data?.take(MESSAGE_CHAR_LENGTH)).append(", ")
            .append("errors: ").append(errors).append(", ")
            .append("conflicts: ").append(conflicts).append(", ")
            .append("importCount: ").append(importCount).append(", ")
            .append("lastImported: ").append(lastImported).append(", ")
            .append("reference: ").append(reference).append(", ")
            .append("succeeded: ").append(succeeded).append(", ")
            .append("status: ").append(status).append(", ")
            .append("success: ").append(success).append(", ")
            .append("message: ").append(message)
            .append("]").toString()
    }
}
