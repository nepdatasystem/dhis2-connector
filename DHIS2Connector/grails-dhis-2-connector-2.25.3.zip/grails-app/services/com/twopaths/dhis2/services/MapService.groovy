package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional
import groovyx.net.http.ContentType

@Transactional
class MapService {

    final def PATH = "/maps"

    def apiService

    /**
     * Finds all maps that contain the supplied programDataElement
     *
     * @param auth DHIS 2 credentials
     * @param programDataElementId Id of the program data element to find maps for
     * @param fields Map fields to return
     * @param apiVersion DHIS 2 api version
     * @return found maps if any
     */
    def findByProgramDataElementId (def auth, def programDataElementId, ArrayList<String> fields = [],
                                    ApiVersion apiVersion = null) {

        def queryParams = [filter: "mapViews.dataDimensionItems.programDataElement.id:eq:${programDataElementId}"]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        return find(auth, queryParams, apiVersion)
    }

    /**
     * Finds all maps that contain the supplied programId
     *
     * @param auth DHIS 2 credentials
     * @param programId Id of the program to find maps for
     * @param fields Map fields to return
     * @param apiVersion DHIS 2 api version
     * @return found maps if any
     */
    def findByProgramId (def auth, def programId, ArrayList<String> fields = [],
                                  ApiVersion apiVersion = null) {

        def queryParams = [filter: "mapViews.program.id:eq:${programId}"]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        return find(auth, queryParams, apiVersion)
    }

    /**
     * Finds all maps that contain the supplied programDataElement
     *
     * @param auth DHIS 2 credentials
     * @param programAttributeId Id of the program attribute to find maps for
     * @param fields Map fields to return
     * @param apiVersion DHIS 2 api version
     * @return found maps if any
     */
    def findByProgramAttributeId (def auth, def programAttributeId, ArrayList<String> fields = [],
                                  ApiVersion apiVersion = null) {

        def queryParams = [filter: "mapViews.dataDimensionItems.programAttribute.id:eq:${programAttributeId}"]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        return find(auth, queryParams, apiVersion)
    }

    /**
     * Finds Maps based off supplied query params
     *
     * @param auth DHIS 2 credentials
     * @param query
     * @param apiVersion
     * @return maps found
     */
    def find (def auth, def query = [:], ApiVersion apiVersion = null) {

        def maps = apiService.get(auth, "${PATH}", query, null, apiVersion)?.data?.maps

        log.debug "maps: " + maps

        return maps

    }

    /**
     * Deletes a map
     *
     * @param auth DHIS 2 credentials
     * @param mapId Id of the map to delete
     * @param apiVersion version of the DHIS 2 API to use
     * @return the Result of the deletion
     */
    def delete(def auth, def MapId, ApiVersion apiVersion = null) {

        log.debug ">>> map: " + MapId

        def path = "${PATH}/${MapId}"

        def result = apiService.delete(auth, path, [:], ContentType.JSON, apiVersion)

        log.debug "<<< map, result: " + result

        return result

    }
}
