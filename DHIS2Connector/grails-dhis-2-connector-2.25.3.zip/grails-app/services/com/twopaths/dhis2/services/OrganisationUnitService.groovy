package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional
import groovyx.net.http.ContentType

@Transactional
class OrganisationUnitService {

    final def PATH = "/organisationUnits"
    
    def apiService

    def getLookup(def auth, ArrayList<String> fields = ["id", "code"],
                  ApiVersion apiVersion = null) {

        def queryParams = [:]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }
        
        def lookup = [:]
        
        def allOrganisationUnits = []
        
        // Get the first page of organisation units
        def organisationUnits = apiService.get(auth, "${PATH}", queryParams, null,
                apiVersion)?.data?.organisationUnits

        if (organisationUnits) {
            allOrganisationUnits.addAll(organisationUnits)
        
            // Create the lookup from the organization units 
            allOrganisationUnits.each { organisationUnit ->
                lookup << [("${organisationUnit.code}"?.toString()?.toLowerCase()): organisationUnit.id]
            }
        }
        
        return lookup
    }
    
    def findByLevel(def auth, def level, ArrayList<String> fields = [],
                    ApiVersion apiVersion = null) {

        def queryParams = [filter: "level:eq:${level}"]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }


        def orgUnits = apiService.get(auth, "${PATH}", queryParams, null, apiVersion)?.data?.organisationUnits
        
        return orgUnits?.collect { orgUnit -> orgUnit.id }
    }

    def findByCode(def auth, def code, ArrayList<String> fields = [],
                   ApiVersion apiVersion = null) {

        def queryParams = [filter: "code:eq:${code}"]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def orgUnits = apiService.get(auth, "${PATH}", queryParams, null, apiVersion)?.data?.organisationUnits

        def orgUnit
        if (orgUnits.size() == 1) {
            orgUnit = orgUnits[0]
        }

        return orgUnit
    }

    def get(def auth, def id, ArrayList<String> fields = [],
            ApiVersion apiVersion = null) {

        def queryParams = [:]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def orgUnit = apiService.get(auth, "${PATH}/${id}", queryParams, null, apiVersion)?.data

        log.debug "orgUnit: " + orgUnit

        return orgUnit
    }

    def update(def auth, def orgUnit, def query = [:], ApiVersion apiVersion = null) {

        def result = apiService.put(auth, PATH, orgUnit, orgUnit.id, query, ContentType.JSON, apiVersion)

        return result

    }

}
