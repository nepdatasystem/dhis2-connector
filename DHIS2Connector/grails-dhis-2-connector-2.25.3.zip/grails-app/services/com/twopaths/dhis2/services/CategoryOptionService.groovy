package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional
import groovyx.net.http.ContentType

@Transactional
class CategoryOptionService {

    final def PATH = "/categoryOptions"
    
    def apiService

    def get(def auth, def id, ArrayList<String> fields = [],
            ApiVersion apiVersion = null) {

        def queryParams = [:]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def categoryOption = apiService.get(auth, "${PATH}/${id}", queryParams, null,
                apiVersion)?.data

        log.debug "categoryOption: " + categoryOption

        return categoryOption
    }

    def findByName(def auth, def name, ArrayList<String> fields = [],
                   ApiVersion apiVersion = null) {

        def queryParams = [filter: "name:eq:${name}"]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def categoryOptions = apiService.get(auth, "${PATH}", queryParams, null, apiVersion)?.data?.categoryOptions

        log.debug "categoryOptions: " + categoryOptions

        def categoryOption
        if (categoryOptions.size() == 1) {
            categoryOption = categoryOptions[0]
        }

        log.debug "categoryOption: " + categoryOption

        return categoryOption
    }

    def findAll(def auth, ApiVersion apiVersion = null) {

        def categoryOptions = apiService.get(auth, "${PATH}", [:], null, apiVersion)?.data

        log.debug "categoryOptions: " + categoryOptions

        return categoryOptions
    }

    def create(def auth, def categoryOption, ApiVersion apiVersion = null) {
        
        log.debug ">>> create categoryOption: " + categoryOption
        
        // remove the id
        categoryOption.remove('id')
        
        def result = apiService.post(auth, PATH, categoryOption, [:], ContentType.JSON, apiVersion)
        
        log.debug "<<< create categoryOption, result: " + result

        return result
    }
    
    
}
