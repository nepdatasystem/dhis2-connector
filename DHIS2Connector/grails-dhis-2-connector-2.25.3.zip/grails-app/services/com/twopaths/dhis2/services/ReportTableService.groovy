package com.twopaths.dhis2.services

import grails.transaction.Transactional
import com.twopaths.dhis2.api.ApiVersion
import groovyx.net.http.ContentType

@Transactional
class ReportTableService {

    final def PATH = "/reportTables"

    def apiService

    /**
     * Finds all report tables that contain the supplied programDataElement
     *
     * @param auth DHIS 2 credentials
     * @param programDataElementId Id of the program data element to find report tables for
     * @param fields Report Table fields to return
     * @param apiVersion DHIS 2 api version
     * @return found report tables if any
     */
    def findByProgramDataElementId (def auth, def programDataElementId, ArrayList<String> fields = [],
                                  ApiVersion apiVersion = null) {

        def queryParams = [filter: "dataDimensionItems.programDataElement.id:eq:${programDataElementId}"]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        return find(auth, queryParams, apiVersion)
    }

    /**
     * Finds all report tables that contain the supplied programDataElement
     *
     * @param auth DHIS 2 credentials
     * @param programAttributeId Id of the program attribute to find report tables for
     * @param fields Report table fields to return
     * @param apiVersion DHIS 2 api version
     * @return found report tables if any
     */
    def findByProgramAttributeId (def auth, def programAttributeId, ArrayList<String> fields = [],
                                  ApiVersion apiVersion = null) {

        def queryParams = [filter: "dataDimensionItems.programAttribute.id:eq:${programAttributeId}"]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        return find(auth, queryParams, apiVersion)
    }

    /**
     * Finds Report Tables based off supplied query params
     *
     * @param auth DHIS 2 credentials
     * @param query
     * @param apiVersion
     * @return reportTables found
     */
    def find (def auth, def query = [:], ApiVersion apiVersion = null) {

        def reportTables = apiService.get(auth, "${PATH}", query, null, apiVersion)?.data?.reportTables

        log.debug "reportTables: " + reportTables

        return reportTables

    }

    /**
     * Deletes a report table (favourite)
     *
     * @param auth DHIS 2 credentials
     * @param reportTableId Id of the report table to delete
     * @param apiVersion version of the DHIS 2 API to use
     * @return the Result of the deletion
     */
    def delete(def auth, def reportTableId, ApiVersion apiVersion = null) {

        log.debug ">>> reportTable: " + reportTableId

        def path = "${PATH}/${reportTableId}"

        def result = apiService.delete(auth, path, [:], ContentType.JSON, apiVersion)

        log.debug "<<< reportTable, result: " + result

        return result

    }

}
