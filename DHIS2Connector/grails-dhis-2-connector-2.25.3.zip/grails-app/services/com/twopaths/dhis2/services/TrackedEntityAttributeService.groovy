package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiMergeMode
import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional
import groovyx.net.http.ContentType

@Transactional
class TrackedEntityAttributeService {

    final def PATH = "/trackedEntityAttributes"
    
    def apiService

    def create(def auth, def trackedEntityAttribute, ApiVersion apiVersion = null) {
        
        def result = apiService.post(auth, PATH, trackedEntityAttribute, [:], ContentType.JSON, apiVersion)
        
        return result
    }

    def update(def auth, def trackedEntityAttribute, def mergeMode = ApiMergeMode.REPLACE, def query = [:],
               ApiVersion apiVersion = null) {

        query.put("mergeMode", mergeMode.value())

        def result = apiService.put(auth, PATH, trackedEntityAttribute, trackedEntityAttribute.id, query,
                ContentType.JSON, apiVersion)
        
        log.debug "update, result: " + result
        
        return result
    }

    def delete (def auth, def trackedEntityAttributeId, ApiVersion apiVersion = null) {

        def path = "${PATH}/${trackedEntityAttributeId}"

        def result = apiService.delete(auth, path, [:], ContentType.JSON, apiVersion)

        return result
    }

    def findByCode(def auth, def code, ArrayList<String> fields = [":all"],
                   ApiVersion apiVersion = null) {

        def queryParams = [filter: "code:eq:${code}"]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def data = apiService.get(auth, "${PATH}", queryParams, null, apiVersion)?.data
                        
        def trackedEntityAttribute

        if (data?.trackedEntityAttributes) {
            trackedEntityAttribute = data?.trackedEntityAttributes[0]
        }
        
        log.debug "trackedEntityAttribute: " + trackedEntityAttribute
        
        return trackedEntityAttribute
    }

    def getIdFromCode(def auth, def code, ApiVersion apiVersion = null) {
        
        log.debug "getIdFromCode, code: " + code
        
        def trackedEntityAttribute = findByCode(auth, code, ["id"], apiVersion)
        
        if (trackedEntityAttribute) {
            return trackedEntityAttribute.id
        } else {
            return null
        }
    }
    
    
    def getLookup(def auth, ArrayList<String> fields = [":all"], ApiVersion apiVersion = null) {

        def queryParams = [:]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }
        
        def lookup = [:]
        
        def allTrackedEntityAttributes = []
        
        def trackedEntityAttributes = apiService.get(auth, "${PATH}", queryParams, null, apiVersion)?.data
        
        if (trackedEntityAttributes) {
            allTrackedEntityAttributes.addAll(trackedEntityAttributes.trackedEntityAttributes)
        
            // Create the lookup from the tracked entity attributes
            allTrackedEntityAttributes.each { trackedEntityAttribute ->
                lookup << [("${trackedEntityAttribute.code}".toString()): trackedEntityAttribute]
            }
        }
        
        return lookup
    }
}
