package com.twopaths.dhis2.services

import grails.transaction.Transactional

@Transactional
class ProgramStageService {
    
    def PATH = "/api/programStages"
    def PATH_PROGRAM_STAGE_DATA_ELEMENTS = "/programStageDataElements"
    
    def apiService
    
    def get(def auth, def programStageId, def query=[:]) {
        log.debug "programStage.get, programStageId: ${programStageId}"
        
        def programStage = apiService.get(auth, "${PATH}/${programStageId}", query)?.data
        
        log.debug "programStage: ${programStage}"
        
        return programStage
    }
    
    def create(def auth, def programStage) {
        
        log.debug "programStage.create"
        def created = apiService.post(auth, PATH, programStage)
        
        log.debug "programStage: " + created
        
        return created
    }
    
    def update(def auth, def programStage) {
        
        log.debug "programStage.update"
        apiService.put(auth, PATH, programStage, programStage.id, [strategy: "CREATE_AND_UPDATE"])
    }
    
    def assignProgramStageDataElement(def auth, def programStageId, def programStageDataElementId) {
        def json = apiService.post(auth, PATH + "/" + programStageId + PATH_PROGRAM_STAGE_DATA_ELEMENTS + "/" + programStageDataElementId)
    }
    
    def findAll(def auth, def query=[fields: ":all"]) {
        log.debug "programStage.findAll"
        def programStages = apiService.get(auth, "${PATH}", query)?.data

        return programStages
    }
    
    def findAllProgramStageDataElements(def auth, def programStageId) {
        def programStageDataElements = apiService.get(auth, PATH + "/" + programStageId + PATH_PROGRAM_STAGE_DATA_ELEMENTS)?.data
        
        return programStageDataElements
    }
}
