package com.twopaths.dhis2.services

import grails.transaction.Transactional

@Transactional
class DataValueService {

    def PATH = "/api/dataValueSets"

    def apiService

    def create(def auth, def dataValue) {

        def json = apiService.post(auth, PATH, dataValue)

        log.debug "<<< dataValue: " + dataValue

        return json

    }

    def read (def auth, def dataSetId, def orgUnitId, def limit = null,
              def startDate = "1970-01-01", def endDate="2100-01-01", def children = true) {
        def queryParams = [
                dataSet: dataSetId,
                orgUnit: orgUnitId,
                startDate: startDate,
                endDate: endDate,
                children: children
        ]
        if (limit && limit > 0) {
            queryParams.put("limit", limit)
        }

        def response = apiService.get(auth, PATH, queryParams)?.data
        response = response?.dataValues
        return response
    }
}
