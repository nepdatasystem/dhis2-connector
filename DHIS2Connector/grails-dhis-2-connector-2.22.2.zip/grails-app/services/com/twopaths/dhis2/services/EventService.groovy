package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.Result

class EventService {
    
    def PATH = "/api/events"
    
    def apiService

    def create(def auth, def event) {
        def result = apiService.post(auth, PATH, event)
        log.debug "create, result: ${result}"
        return result
    }

    // TODO: Fix when the response changes
    def update(def auth, def event, def eventId) {
        def result = apiService.put(auth, PATH, event, eventId, [:])

        def message = result?.message

        // TODO: Hack to cater for the fact that a 'response' is not returned so we just check for the content of the message field and construct fake data
        if (message?.startsWith("Import was successful.")) {
            result = new Result("update", [response: [responseType: "ImportSummaries", importSummaries: [[importCount:[updated: 1, ignored: 0]]]]], 200)
        } else {
            result = new Result("update", [response: [responseType: "ImportSummaries", importSummaries: [[importCount:[updated: 0, ignored: 1]]]]], null)
        }

        return result
    }
    
    def findByQuery(def auth, def query) {
        def events = apiService.get(auth, PATH, query)?.data
        log.debug "findByQuery, events: ${events}"
        
        return events
    }
    
    def findByProgramStageIdAndTrackedEntityInstanceId(def auth, def programStageId, def trackedEntityInstanceId) {
        def event = apiService.get(auth, PATH, [programStage: programStageId, trackedEntityInstance: trackedEntityInstanceId])?.data
        log.debug "findByProgramStageIdAndTrackedEntityInstanceId, event: ${event}"
        return event
    }
    
    def get(def auth, def code) {
        def event = apiService.get(auth, "${PATH}")?.data
        log.debug "get, event: ${event}"
        return event
    }
}
