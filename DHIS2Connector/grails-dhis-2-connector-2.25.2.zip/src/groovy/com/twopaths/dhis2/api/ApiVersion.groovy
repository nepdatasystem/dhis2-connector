package com.twopaths.dhis2.api

/**
 * Which version of the DHIS 2 API should be used
 */
enum ApiVersion {


    /* Version 2.23 of the API. As of 2.23, this is only used for the /api/metadata API call */
    DHIS2_VERSION_223 ("2.23", "/23"),

    /* Version 2.24 of the API. As of 2.24, the majority of the API has been versioned. See comments
     * in ApiResultParser224Service.groovy */
    DHIS2_VERSION_224 ("2.24", "/24"),

    /* Version 2.25 of the API
     */
    DHIS2_VERSION_225 ("2.25", "/25")


    private static Map<String, ApiVersion> lookup = new HashMap<String, ApiVersion>()

    static {
        for (ApiVersion apiVersion : ApiVersion.values()) {
            lookup.put(apiVersion.value(), apiVersion);
        }
    }

    private String name

    private String apiVersionSubPath

    private ApiVersion (String name, String apiVersionSubPath) {
        this.name = name
        this.apiVersionSubPath = apiVersionSubPath
    }

    public String value() {
        name
    }

    public String getApiVersionSubPath () {
        apiVersionSubPath
    }

    public static ApiVersion get(String name) {
        return lookup.get(name);
    }
}