package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional
import groovyx.net.http.ContentType

@Transactional
class CategoryOptionComboService {

    final def PATH = "/categoryOptionCombos"
    final def CATEGORY_OPTIONS_SUB_PATH = "categoryOptions"

    def apiService

    def get(def auth, def id, ArrayList<String> fields = [],
            ApiVersion apiVersion = null) {

        def queryParams = [:]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def categoryOptionCombo = apiService.get(auth, "${PATH}/${id}", queryParams, null,
                apiVersion)?.data

        log.debug "categoryOptionCombo: " + categoryOptionCombo

        return categoryOptionCombo
    }

    def findByName(def auth, def name, ArrayList<String> fields = [],
                   ApiVersion apiVersion = null) {

        def queryParams = [filter: "name:eq:${name}"]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def categoryOptionCombos = apiService.get(auth, "${PATH}", queryParams, null, apiVersion)?.data?.categoryOptionCombos

        log.debug "categoryOptionCombos: " + categoryOptionCombos

        def categoryOptionCombo
        if (categoryOptionCombos.size() == 1) {
            categoryOptionCombo = categoryOptionCombos[0]
        }

        log.debug "categoryOptionCombo: " + categoryOptionCombo

        return categoryOptionCombo
    }

    def findAll(def auth, ApiVersion apiVersion = null) {

        def categoryOptionCombos = apiService.get(auth, "${PATH}", [:], null, apiVersion)?.data

        log.debug "categoryOptionCombos: " + categoryOptionCombos

        return categoryOptionCombos
    }

    def create(def auth, def categoryOptionCombo, ApiVersion apiVersion = null) {

        log.debug ">>> create categoryOptionCombo: " + categoryOptionCombo

        // remove the id
        categoryOptionCombo.remove('id')

        def result = apiService.post(auth, PATH, categoryOptionCombo, [:], ContentType.JSON, apiVersion)

        log.debug "<<< create categoryOptionCombo. result: " + result

        return result

    }

    def delete(def auth, def categoryOptionComboId, ApiVersion apiVersion = null) {
        log.debug ">>> categoryOptionCombo: " + categoryOptionComboId

        def result = apiService.delete(auth, PATH, categoryOptionComboId, [:], ContentType.JSON, apiVersion)

        log.debug "<<< categoryOptionCombo, result: " + result

        return result
    }


    def assignCategoryOptionToCategoryOptionCombo(def auth, def categoryOptionComboId, def categoryOptionId,
                                                  ApiVersion apiVersion = null) {

        log.debug ">>> categoryOptionComboId: " + categoryOptionComboId

        log.debug "${PATH}/${categoryOptionComboId}/${CATEGORY_OPTIONS_SUB_PATH}/${categoryOptionId}"

        def json = apiService.post(auth, "${PATH}/${categoryOptionComboId}/${CATEGORY_OPTIONS_SUB_PATH}/${categoryOptionId}"
                , null, [:], ContentType.JSON, apiVersion )

        return json
    }

}
