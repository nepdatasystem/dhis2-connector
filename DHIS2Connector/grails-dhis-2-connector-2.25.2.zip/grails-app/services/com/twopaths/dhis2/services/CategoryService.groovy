package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional
import groovyx.net.http.ContentType

@Transactional
class CategoryService {

    final def PATH = "/categories"
    final def CATEGORY_OPTIONS_SUB_PATH = "categoryOptions"

    def apiService

    def get(def auth, def id, ArrayList<String> fields = [],
            ApiVersion apiVersion = null) {

        def queryParams = [:]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def category = apiService.get(auth, "${PATH}/${id}", queryParams, null,
                apiVersion)?.data

        log.debug "category: " + category

        return category
    }

    def findByName(def auth, def name, ArrayList<String> fields = [],
                   ApiVersion apiVersion = null) {

        def queryParams = [filter: "name:eq:${name}"]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def categories = apiService.get(auth, "${PATH}", queryParams, null, apiVersion)?.data?.categories

        log.debug "categories: " + categories

        def categoryOption
        if (categories.size() == 1) {
            categoryOption = categories[0]
        }

        log.debug "categoryOption: " + categoryOption

        return categoryOption
    }

    def findAll(def auth, ArrayList<String> fields = [], ApiVersion apiVersion = null) {

        def queryParams = [:]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def categories = apiService.get(auth, "${PATH}", queryParams, null, apiVersion)?.data

        log.debug "categories: " + categories

        return categories
    }

    def create(def auth, def category, ApiVersion apiVersion = null) {

        log.debug ">>> create category: " + category

        // remove the id
        category.remove('id')

        def result = apiService.post(auth, PATH, category, [:], ContentType.JSON, apiVersion)

        log.debug "<<< create category, result: " + result

        return result
    }

    def assignCategoryOptionToCategory(def auth, def categoryId, def categoryOptionId,
                                       ApiVersion apiVersion = null) {

        log.debug ">>> categoryId: " + categoryId

        def json = apiService.post(auth, "${PATH}/${categoryId}/${CATEGORY_OPTIONS_SUB_PATH}/${categoryOptionId}",
                null, [:], ContentType.JSON, apiVersion )

        return json
    }

}
