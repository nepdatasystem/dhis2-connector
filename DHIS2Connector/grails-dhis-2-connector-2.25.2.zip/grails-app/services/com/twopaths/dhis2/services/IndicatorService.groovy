package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional
import groovyx.net.http.ContentType

@Transactional
class IndicatorService {

    final def PATH = "/indicators"

    def apiService

    def findAllByDataElement(def auth, def dataElementID, ArrayList<String> fields = [],
                   ApiVersion apiVersion = null) {

        // in order to find indicators that use the specified data element, have to search if the ID is included in
        // either the numerator or the denominator. Can use the logical operator of "OR" to join the 2 portions of the
        // query using the "rootJunction" functionality in DHIS 2
        // https://docs.dhis2.org/2.25/en/developer/html/webapi_metadata_object_filter.html#webapi_metadata_logical_operator
        def queryParams = [
                rootJunction: "OR"
        ]
        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        // have to send this as a queryString because the filter param is deliberately supplied twice and therefore
        // cannot be supplied as the key in the queryParams map as map keys need to be unique
        def queryString = "filter=numerator:like:${dataElementID}&filter=denominator:like:${dataElementID}".toString()

        def indicators = apiService.get(auth, "${PATH}", queryParams, queryString, apiVersion)?.data?.indicators

        log.debug "indicators: " + indicators

        return indicators
    }

    def delete (def auth, def indicatorID, ApiVersion apiVersion = null) {

        log.debug ">>> indicator: ${indicatorID}"

        def result = apiService.delete(auth, PATH, indicatorID, [:], ContentType.JSON, apiVersion)

        log.debug "<<< indicator, result: " + result

        return result
    }
}
