package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional
import groovyx.net.http.ContentType

@Transactional
class MetadataService {

    final def PATH = "/metadata"

    def apiService

    /*
     * Possible versions for the metadata API as of v 2.25:
     * - ApiVersion.DHIS2_VERSION_223
     * - ApiVersion.DHIS2_VERSION_224
     * - ApiVersion.DHIS2_VERSION_225
     */
    def createOrUpdate(def auth, def metadata, def query = [:], ApiVersion apiVersion = null) {

        log.debug ">>> create metadata: " + metadata

        def result = apiService.post(auth, PATH, metadata, query, ContentType.JSON, apiVersion)

        log.debug "<<< createOrUpdate metadata, result: " + result

        return result
    }
}
