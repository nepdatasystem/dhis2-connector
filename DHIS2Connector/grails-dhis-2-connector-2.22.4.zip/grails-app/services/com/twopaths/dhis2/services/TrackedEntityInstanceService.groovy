package com.twopaths.dhis2.services

import grails.transaction.Transactional

@Transactional
class TrackedEntityInstanceService {
    
    def PATH = "/api/trackedEntityInstances"
    
    def apiService

    def create(def auth, def trackedEntityInstance, def query=null) {
        def result = apiService.post(auth, PATH, trackedEntityInstance, query)
        log.debug "create, result: " + result
        return result
    }
    
    def update(def auth, def trackedEntityInstance, def trackedEntityInstanceId, def query=null) {
        def result = apiService.put(auth, PATH, trackedEntityInstance, trackedEntityInstanceId, query)
        log.debug "update, result: " + result
        return result
    }
    
    def get(def auth, def code) {
        log.debug "get, code: " + code
        def trackedEntityInstance = apiService.get(auth, "${PATH}")?.data
        log.debug "trackedEntityInstance: " + trackedEntityInstance
        return trackedEntityInstance
    }
    
    def findByQuery(def auth, def query=[:]) {
        
            def trackedEntities = apiService.get(auth,  "${PATH}", query)?.data
            
            return trackedEntities
    }
    
    def getIdByOrgUnitAttributeAndValue(def auth, def orgUnit, def attribute, def value) {
        
        log.debug "getIdByOrgUnitAttributeAndValue, orgUnit: ${orgUnit}, attribute: ${attribute}, value: ${value}"
        def id
        
        def trackedEntityInstances = apiService.get(auth, "${PATH}", [ou:orgUnit, filter: "${attribute}:eq:${value}"])?.data

        if (trackedEntityInstances?.trackedEntityInstances) {
            if (trackedEntityInstances?.trackedEntityInstances?.size() == 1) {
                id =  trackedEntityInstances.trackedEntityInstances[0].trackedEntityInstance
            } else if (trackedEntityInstances?.trackedEntityInstances?.size() == 0) {
                log.error "No rows for orgUnit: " + orgUnit + " and attribute: " + attribute
            } else {
                log.error "Multiple rows for orgUnit: " + orgUnit + " and attribute: " + attribute
            }
        }
        
        log.debug "trackedEntityInstance id: " + id
        
        // Return the id
        return id
    }
    
    def getLookup(def auth) {
        
        def lookup = [:]
        
        def allTrackedEntityInstances = []
        
        def trackedEntityInstances = apiService.get(auth, "${PATH}", [fields: ":all"])?.data
        
        allTrackedEntityInstances.addAll(trackedEntityInstances.trackedEntityInstances)
        
        // Create the lookup from the tracked entity attributes
        allTrackedEntityInstances.each { trackedEntityInstance ->
            lookup << [("${trackedEntityInstance.code}".toString()): trackedEntityInstance]
        }
        
        return lookup
    }
}
