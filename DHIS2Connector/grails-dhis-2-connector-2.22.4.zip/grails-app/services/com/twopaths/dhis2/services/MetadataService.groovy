package com.twopaths.dhis2.services

import grails.transaction.Transactional

@Transactional
class MetadataService {

    def PATH = "/api/metadata"

    def apiService

    def createOrUpdate(def auth, def metadata) {

        log.debug ">>> create metadata: " + metadata

        def result = apiService.post(auth, PATH, metadata)

        log.debug "<<< createOrUpdate metadata, result: " + result

        return result
    }
}
