package com.twopaths.dhis2.services

import grails.transaction.Transactional

@Transactional
class CategoryOptionService {
    
    def PATH = "/api/categoryOptions"
    
    def apiService

    def get(def auth, def id) {

        def categoryOption = apiService.get(auth, "${PATH}/${id}")?.data

        log.debug "categoryOption: " + categoryOption

        return categoryOption
    }
    def findByName(def auth, def name) {

        def categoryOptions = apiService.get(auth, "${PATH}", [filter: "name:eq:${name}"])?.data?.categoryOptions

        log.debug "categoryOptions: " + categoryOptions

        def categoryOption
        if (categoryOptions.size() == 1) {
            categoryOption = categoryOptions[0]
        }

        log.debug "categoryOption: " + categoryOption

        return categoryOption
    }

    def findAll(def auth) {

        def categoryOptions = apiService.get(auth, "${PATH}")?.data

        log.debug "categoryOptions: " + categoryOptions

        return categoryOptions
    }

    def create(def auth, def categoryOption) {
        
        log.debug ">>> create categoryOption: " + categoryOption
        
        // remove the id
        categoryOption.remove('id')
        
        def result = apiService.post(auth, PATH, categoryOption)
        
        log.debug "<<< create categoryOption, result: " + result

        return result
    }
    
    
}
