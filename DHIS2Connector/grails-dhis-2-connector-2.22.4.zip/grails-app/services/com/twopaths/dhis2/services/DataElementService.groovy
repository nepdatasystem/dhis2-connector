package com.twopaths.dhis2.services

import grails.transaction.Transactional
import groovyx.net.http.ContentType

@Transactional
class DataElementService {
    
    def PATH = "/api/dataElements"
    def DATASET_SUB_PATH = "dataSets"

    public final String MERGE_STRATEGY_REPLACE = "REPLACE"
    public final String MERGE_STRATEGY_IF_NOT_NULL = "MERGE_IF_NOT_NULL"

    public final String ALL_FIELDS = ":all"
    public final String FIELD_VALUE_TYPE = "valueType"
    public final String FIELD_CATEGORY_COMBO = "categoryCombo[:identifiable]"
    public final String FIELD_ID = "id"
    
    def apiService

    def create(def auth, def dataElement) {

        log.debug ">>> dataElement: " + dataElement

        // remove the id
        dataElement.remove('id')
        def result = apiService.post(auth, PATH, dataElement, [:], ContentType.ANY)

        log.debug "<<< result: " + result

        return result
    }
    
    def update(def auth, def dataElement, def mergeStrategy = MERGE_STRATEGY_REPLACE) {
        
        def result = apiService.put(auth, PATH, dataElement, dataElement.id, [mergeStrategy: mergeStrategy])
        
        log.debug "update, result: " + result
        
        return result
    }

    def get(def auth, def id) {

        def dataElement = apiService.get(auth, "${PATH}/${id}")?.data

        log.debug "dataElement: " + dataElement

        return dataElement
    }

    def findByName(def auth, def name, ArrayList<String> fields = []) {

        def queryParams = [filter: "name:eq:${name}"]
        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def dataElements = apiService.get(auth, "${PATH}", queryParams)?.data?.dataElements

        log.debug "dataElements: " + dataElements

        def dataElement
        if (dataElements.size() == 1) {
            dataElement = dataElements[0]
        }


        return dataElement
    }

    def findByCode(def auth, def code) {

        def dataElements = apiService.get(auth, "${PATH}", [filter: "code:eq:${code}", fields: ":all"])?.data?.dataElements

        log.debug "dataElements: " + dataElements

        def dataElement
        if (dataElements.size() == 1) {
            dataElement = dataElements[0]
        }


        return dataElement
    }

    def findByUID(def auth, def UID) {

        def dataElement = apiService.get(auth, "$PATH/" + UID, [fields: ":all"])

        return dataElement
    }

    def getLookup(def auth) {
        
        def lookup = [:]
        
        def allDataElements = []
        
        def dataElements = apiService.get(auth, "${PATH}", [fields: ":all"])?.data
        
        if (dataElements) {
            allDataElements.addAll(dataElements.dataElements)
        
            // Create the lookup from the organization units
            allDataElements.each { dataElement ->
                lookup << [("${dataElement.code}".toString()): dataElement]
            }
        }
        return lookup
    }

    def assignDataSetToDataElement(def auth, def dataElementId, def dataSetId) {
        log.debug ">>> dataElement: " + dataElementId

        def json = apiService.post(auth, "${PATH}/${dataElementId}/${DATASET_SUB_PATH}/${dataSetId}")

        return json
    }

}
