package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional
import groovyx.net.http.ContentType

@Transactional
class MetadataService {

    def API_PATH = "/api"
    def API_SUB_PATH = "/metadata"

    def apiService

    /*
     * Possible versions for the metadata API as of v 2.23:
     * - ApiVersion.DHIS2_DEFAULT_VERSION
     * - ApiVersion.DHIS2_VERSION_223
     */
    def createOrUpdate(def auth, def metadata, def query = [:], ApiVersion apiVersion = ApiVersion.DHIS2_DEFAULT_VERSION) {

        log.debug ">>> create metadata: " + metadata

        def path = API_PATH + apiVersion.apiVersionSubPath + API_SUB_PATH

        def result = apiService.post(auth, path, metadata, query, ContentType.JSON, apiVersion)

        log.debug "<<< createOrUpdate metadata, result: " + result

        return result
    }
}
