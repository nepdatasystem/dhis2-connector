package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiStrategy
import grails.transaction.Transactional

@Transactional
class ProgramStageDataElementService {
    
    def PATH = "/api/programStageDataElements"
    
    def apiService
    
    def create(def auth, def programStageDataElement) {
        
        log.debug "programStageDataElement.create"
        def result = apiService.post(auth, PATH, programStageDataElement)
        
        log.debug "programStage: " + result
        
        return result
    }
    
    def update(def auth, def programStageDataElement) {
        
        log.debug "programStageDataElement.update"
        apiService.put(auth, PATH, programStageDataElement, programStageDataElement.id, [strategy: ApiStrategy.CREATE_AND_UPDATE.value()])
    }
    
    def findAll(def auth) {
        log.debug "programStageDataElements.findAll"
        def programStageDataElements = apiService.get(auth, "${PATH}", [fields: ":all"])?.data

        return programStageDataElements
    }
}
