package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiMergeMode
import grails.transaction.Transactional

@Transactional
class TrackedEntityAttributeService {
    
    def PATH = "/api/trackedEntityAttributes"
    
    def apiService

    def create(def auth, def trackedEntityAttribute) {
        
        def json = apiService.post(auth, PATH, trackedEntityAttribute)
        
        return json
    }
    
    def update(def auth, def trackedEntityAttribute, def mergeStrategy = ApiMergeMode.REPLACE.value()) {
        
        def json = apiService.put(auth, PATH, trackedEntityAttribute, trackedEntityAttribute.id, [mergeStrategy: mergeStrategy])
        
        log.debug "update, json: " + json
        
        return json
    }
    
    def findByCode(def auth, def code) {
        
        def data = apiService.get(auth, "${PATH}", [filter: "code:eq:${code}", fields: ":all"])?.data
                        
        def trackedEntityAttribute
        if (data?.trackedEntityAttributes) {
            trackedEntityAttribute = data?.trackedEntityAttributes[0]
        }
        
        log.debug "trackedEntityAttribute: " + trackedEntityAttribute
        
        return trackedEntityAttribute
    }
    
    def getIdFromCode(def auth, def code) {
        
        log.debug "getIdFromCode, code: " + code
        
        def trackedEntityAttributes = apiService.get(auth, "${PATH}", [filter: "code:eq:${code}"])?.data
        
        if (trackedEntityAttributes) {
            return trackedEntityAttributes.trackedEntityAttributes[0]?.id
        } else {
            return null
        }
    }
    
    
    def getLookup(def auth) {
        
        def lookup = [:]
        
        def allTrackedEntityAttributes = []
        
        def trackedEntityAttributes = apiService.get(auth, "${PATH}", [fields: ":all"])?.data
        
        if (trackedEntityAttributes) {
            allTrackedEntityAttributes.addAll(trackedEntityAttributes.trackedEntityAttributes)
        
            // Create the lookup from the tracked entity attributes
            allTrackedEntityAttributes.each { trackedEntityAttribute ->
                lookup << [("${trackedEntityAttribute.code}".toString()): trackedEntityAttribute]
            }
        }
        
        return lookup
    }
}
