package com.twopaths.dhis2.services

import grails.transaction.Transactional

@Transactional
class trackedEntityService {
    
    def PATH = "/api/trackedEntities"
    
    def apiService
    
    def findAll(def auth) {
        
        def trackedEntities = apiService.get(auth, "${PATH}", [fields: ":all"])?.data

        return trackedEntities
    }
}
