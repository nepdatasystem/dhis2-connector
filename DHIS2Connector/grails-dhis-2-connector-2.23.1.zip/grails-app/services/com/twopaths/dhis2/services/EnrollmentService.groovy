package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiStrategy
import grails.transaction.Transactional

@Transactional
class EnrollmentService {
    
    def PATH = "/api/enrollments"
    
    def apiService

    def create(def auth, def enrollment, def query=null) {
        def result = apiService.post(auth, PATH, enrollment, query)
        log.debug "create, result: " + result
        return result
    }

    def update(def auth, def enrollment, def query=null) {
        def result = apiService.put(auth, PATH, enrollment, enrollment.id, [strategy: ApiStrategy.CREATE_AND_UPDATE.value()], query)
        log.debug "update, result: " + result
        return result
    }

    def get(def auth, def code) {
        def enrollment = apiService.get(auth, "${PATH}?code=${code}")?.data
        log.debug "get, enrollment: " + enrollment
        return enrollment
    }
    
    def findByQuery(def auth, def query) {
        
        def enrollments = apiService.get(auth,  PATH, query)?.data
        log.debug "enrollments: " + enrollments
        
        return enrollments
    }
    
    def findByOrgUnitAndTrackedEntityInstance(def auth, def orgUnit, def trackedEntityInstanceId) {
        
        def enrollments = apiService.get(auth, "${PATH}", [ou: orgUnit, trackedEntityInstance: trackedEntityInstanceId, fields: ":all"])?.data
        
        log.debug "enrollments: " + enrollments
        
        if (enrollments?.enrollments?.size() == 1) {
            return enrollments.enrollments[0]
        } else {
            log.error "No enrollments found for trackedEntityInstanceId: " + trackedEntityInstanceId
            return null
        }
    }
    
    def getLookup(def auth) {
        
        def lookup = [:]
        
        def allEnrollments = []
        
        def enrollments = apiService.get(auth, "${PATH}", [fields: ":all"])?.data
        
        allEnrollments.addAll(enrollments.enrollments)
        
        // Create the lookup from the tracked entity attributes
        allEnrollments.each { enrollment ->
            lookup << [("${enrollment.code}".toString()): enrollment]
        }
        
        return lookup
    }
}
