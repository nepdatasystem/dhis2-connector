package com.twopaths.dhis2.services

import grails.transaction.Transactional

@Transactional
class CategoryComboService {

    def PATH = "/api/categoryCombos"
    def CATEGORY_SUB_PATH = "categories"

    public final String FIELD_CATEGORY_OPTION_COMBOS = "categoryOptionCombos[:identifiable]"

    def apiService

    def get(def auth, def id, ArrayList<String> fields = []) {

        def queryParams = [:]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def categoryCombo = apiService.get(auth, "${PATH}/${id}", queryParams)?.data

        log.debug "categoryCombo: " + categoryCombo

        return categoryCombo
    }
    def findByName(def auth, def name) {

        def categoryCombos = apiService.get(auth, "${PATH}", [filter: "name:eq:${name}"])?.data?.categoryCombos

        log.debug "categoryCombos: " + categoryCombos

        def categoryCombo
        if (categoryCombos.size() == 1) {
            categoryCombo = categoryCombos[0]
        }

        log.debug "categoryCombo: " + categoryCombo

        return categoryCombo
    }

    def findAll(def auth) {

        def categoryCombos = apiService.get(auth, "${PATH}")?.data

        log.debug "categoryCombos: " + categoryCombos

        return categoryCombos
    }

    def create(def auth, def categoryCombo) {

        log.debug ">>> categoryCombo: " + categoryCombo

        // remove the id
        categoryCombo.remove('id')

        def json = apiService.post(auth, PATH, categoryCombo)

        log.debug "<<< categoryCombo result: " + json

        return json

    }
    def assignCategoryToCategoryCombo(def auth, def categoryComboId, def categoryId) {
        log.debug ">>> categoryComboId: " + categoryComboId

        def json = apiService.post(auth, "${PATH}/${categoryComboId}/${CATEGORY_SUB_PATH}/${categoryId}")

        return json
    }
}
