package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiMergeMode
import com.twopaths.dhis2.api.ApiStrategy
import grails.transaction.Transactional

@Transactional
class ProgramService {

    def PATH = "/api/programs"

    def apiService

    def create(def auth, def program) {

        def created = apiService.post(auth, PATH, program)

        log.debug "program: " + created

        return created
    }

    def update(def auth, def program) {
        // Default mergeMode in 2.24 and prior is "MERGE". Default in 2.25 and higher is "REPLACE"
        apiService.put(auth, PATH, program, program.id, [strategy: ApiStrategy.CREATE_AND_UPDATE.value(), mergeMode: ApiMergeMode.MERGE.value()])
    }

    def findAll(def auth, def query = [fields: ":all"]) {

        def programs = apiService.get(auth, "${PATH}", query)?.data

        return programs
    }

    def get(def auth, def programId, def query=[:]) {

        def program = apiService.get(auth, "${PATH}/${programId}", query)?.data

        log.debug "program: " + program

        return program
    }
}
