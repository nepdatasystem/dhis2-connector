package com.twopaths.dhis2.services

import grails.transaction.Transactional

@Transactional
class UserRoleService {
    
    def PATH = "/api/userRoles"
    def DATASET_SUBPATH="dataSets"
    def PROGRAM_SUBPATH="programs"
    
    def apiService

    def findByRole(def auth, def role) {
        def userRoles = apiService.get(auth, "${PATH}", [filter: "name:eq:${role}"])?.data?.userRoles
        
        log.debug "userRoles: " + userRoles
            
        // Should only be one role....get that and return it
        if (userRoles?.size() == 1) {
            return userRoles[0]
        } else {
            return null
        }
    }
    
    def findByRoles(def auth, def roles) {
        
        // Need to use a queryString for the filter
        
        def queryString = ""
        roles.each { role -> 
            def encodedRole = java.net.URLEncoder.encode(role, "UTF-8")
            queryString += "&filter=name:eq:${encodedRole}"
        }
        if (queryString) {
            queryString = queryString.substring(1)
        }
        
        def userRoles = apiService.get(auth, "${PATH}", [:], queryString)?.data?.userRoles
        
        log.debug "userRoles: " + userRoles
        return userRoles
    }

    def assignDataSetToUserRole(def auth, def userRole, def dataSetId) {

        def json = apiService.post(auth, "${PATH}/${userRole.id}/${DATASET_SUBPATH}/${dataSetId}")

        return json
    }

    def assignProgramToUserRole(def auth, def userRole, def programId) {

        def json = apiService.post(auth, "${PATH}/${userRole.id}/${PROGRAM_SUBPATH}/${programId}")

        return json
    }

}
