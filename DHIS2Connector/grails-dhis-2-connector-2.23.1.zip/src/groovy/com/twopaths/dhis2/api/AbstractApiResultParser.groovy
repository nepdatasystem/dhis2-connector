package com.twopaths.dhis2.api

/**
 * Abstract super class for parsing DHIS 2 API Results based off of DHIS 2 API version.
 * Provides helper method(s) to be used by parsers
 */
abstract class AbstractApiResultParser implements ApiResultParser {


    int getSucceededCount(ApiActionType action, def importCount) {
        def succeeded = 0

        if (importCount) {
            switch (action) {
            // Some POSTs allow update so need to check the imported and updated count...
                case ApiActionType.Import:
                    succeeded = (importCount?.imported ?: 0) + (importCount?.updated ?: 0)
                    break
                case ApiActionType.Update:
                    succeeded = importCount?.updated ?: 0
                    break
                case ApiActionType.Delete:
                    succeeded = importCount?.deleted ?: 0
                    break
            }
        }
        return succeeded
    }

}
