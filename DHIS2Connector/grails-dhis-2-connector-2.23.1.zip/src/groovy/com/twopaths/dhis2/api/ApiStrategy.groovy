package com.twopaths.dhis2.api

/**
 * Supported import/update strategies for DHIS 2.
 * Note that expected values in API are all uppercase
 */
enum ApiStrategy {

    CREATE_AND_UPDATE ("CREATE_AND_UPDATE"),
    CREATE ("CREATE"),
    UPDATE ("UPDATE"),
    DELETE ("DELETE")

    private String name

    private ApiStrategy (String name) {
        this.name = name
    }

    public String value() {
        name
    }

}