package com.twopaths.dhis2.api

/**
 * Enum of types that can be returned by the metadata API
 *
 * Note: there is no concept of translation within the DHIS 2 Connector, it is currently being handled in all
 * implementing applications.
 * DHIS 2 has also not implemented translations for their error handling yet.
 */
enum ApiObjectType {


    /* So far we're only using the metadata API for this subset of API Object Types
     */
    Program (
            "Program",
            "org.hisp.dhis.program.Program",
            "programs"),

    ProgramTrackedEntityAttribute (
            "ProgramTrackedEntityAttribute",
            "org.hisp.dhis.program.ProgramTrackedEntityAttribute",
            "programTrackedEntityAttributes"),

    // Enum to use if the type has not yet been implemented as an enum
    Unimplemented (
            "Not Yet Implemented",
            "N/A",
            "N/A")

    private String name

    private String fullyQualifiedName

    private String pluralizedName

    private ApiObjectType(String name, fullyQualifiedName, pluralizedName){
        this.name = name
        this.fullyQualifiedName = fullyQualifiedName
        this.pluralizedName = pluralizedName
    }

    public String value() {
        name
    }

    public String getPluralizedName () {
        pluralizedName
    }

    String toString() {
        name
    }

    static ApiObjectType getByName( String name ) {
        values().find { it.name == name } ?: Unimplemented
    }

    static ApiObjectType getByFullyQualifiedName( String fullyQualifiedName ) {
        values().find { it.fullyQualifiedName == fullyQualifiedName } ?: Unimplemented
    }

    static String getPluralizedName (ApiObjectType objectType) {
        return objectType.pluralizedName
    }

}