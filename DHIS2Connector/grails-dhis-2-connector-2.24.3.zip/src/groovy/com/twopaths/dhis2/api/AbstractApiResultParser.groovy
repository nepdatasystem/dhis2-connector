package com.twopaths.dhis2.api

import org.apache.commons.lang.StringUtils

/**
 * Abstract super class for parsing DHIS 2 API Results based off of DHIS 2 API version.
 * Provides helper method(s) to be used by parsers
 */
abstract class AbstractApiResultParser implements ApiResultParser {


    int getSucceededCount(ApiActionType action, def importCount) {
        def succeeded = 0

        if (importCount) {
            switch (action) {
            // Some POSTs allow update so need to check the imported and updated count...
                case ApiActionType.Import:
                    succeeded = (importCount?.imported ?: 0) + (importCount?.updated ?: 0)
                    break
                case ApiActionType.Update:
                    succeeded = importCount?.updated ?: 0
                    break
                case ApiActionType.Delete:
                    succeeded = importCount?.deleted ?: 0
                    break
            }
        }
        return succeeded
    }

    /*
     *  The parsers need to extract the object name from the fully qualified name that is used in the API response
     *  EG:
     *  Object Name: "Program"
     *  Fully Qualified Object Name: "org.hisp.dhis.program.Program"
     */
    String getObjectNameFromFullyQualifiedObjectName (String objectName) {
        if (!objectName) {
            return objectName
        } else {
            return objectName.contains(".") ? StringUtils.substringAfterLast(objectName, ".") : objectName
        }
    }

    /*
     *  The parsers need to extract the pluralized object name that is used in the API request
     *  EG:
     *  Object Name: "Program"
     *  Pluralized Name: "programs"
     */
    String getPluralizedObjectNameFromObjectName (String objectName) {
        if (!objectName || objectName.length() == 0) {
            return objectName
        } else {
            return objectName.substring(0,1).toLowerCase() + objectName.substring(1, objectName.length()) + "s"
        }
    }
}
