package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional
import groovyx.net.http.ContentType

@Transactional
class OptionValueService {

    final def PATH = "/options"
    
    def apiService

    def create(def auth, def optionValue, ApiVersion apiVersion = null) {
        
        log.debug ">>> optionValue: " + optionValue
        
        // remove the id
        optionValue.remove('id')
        
        def result = apiService.post(auth, PATH, optionValue, [:], ContentType.JSON, apiVersion)
        
        log.debug "<<< optionValue, result: " + result
        
        return result
    }
    
    def update(def auth, def optionValue, ApiVersion apiVersion = null) {
        
        log.debug ">>> optionValue: " + optionValue
        
        def result = apiService.put(auth, PATH, optionValue, optionValue.id, [:], ContentType.JSON, apiVersion)

        log.debug "<<< result: " + result
        
        return result
    }
    
    def get(def auth, def code, ArrayList<String> fields = [],
            ApiVersion apiVersion = null) {

        def queryParams = [:]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }
        
        def optionValue = apiService.get(auth, "${PATH}?code=${code}", queryParams, null,
                apiVersion)?.data
        
        log.debug "optionValue: " + optionValue
        
        return optionValue
    }
}
