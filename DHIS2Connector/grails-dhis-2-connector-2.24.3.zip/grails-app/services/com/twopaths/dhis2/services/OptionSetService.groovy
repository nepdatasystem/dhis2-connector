package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiMergeMode
import com.twopaths.dhis2.api.ApiStrategy
import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional
import groovyx.net.http.ContentType


@Transactional
class OptionSetService {

    final def PATH = "/optionSets"
    final def PATH_OPTIONS = "/options"
    
    def apiService

    def create(def auth, def optionSet, ApiVersion apiVersion = null) {
        
        def result = apiService.post(auth, PATH, optionSet, [:], ContentType.JSON, apiVersion)
        
        log.debug "create, result: " + result
        
        return result
    }
    
    def addOption(def auth, def optionSetId, def optionValueId,
                  ApiVersion apiVersion = null) {
        
        log.debug ">>> addOption, optionSetId: " + optionSetId + ", optionValueId: " + optionValueId
        
        def result = apiService.post(auth, "$PATH/${optionSetId}$PATH_OPTIONS/${optionValueId}", null, [:],
                ContentType.JSON, apiVersion )
        
        log.debug "<<< addOption: " + result
        
        return result
    }
    
    def update(def auth, def optionSet, ApiStrategy apiStrategy = ApiStrategy.CREATE_AND_UPDATE,
               ApiVersion apiVersion = null) {

        def query = [strategy: apiStrategy.value()]

        def result = apiService.put(auth, PATH, optionSet, optionSet.id, query, ContentType.JSON, apiVersion)
        
        log.debug "update: " + result
        
        return result
    }
    
    def getById(def auth, def id, ArrayList<String> fields = [],
                ApiVersion apiVersion = null) {

        def queryParams = [:]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def optionSet = apiService.get(auth, "$PATH/${id}", queryParams, null, apiVersion)?.data
        
        log.debug "getById, id: " + id + ", optionSet: " + optionSet
        
        return optionSet
    }
    
    def get(def auth, def name, ArrayList<String> fields = [],
            ApiVersion apiVersion = null) {

        def queryParams = [filter: "name:eq:${name}"]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def optionSets = apiService.get(auth, "${PATH}", queryParams, null, apiVersion)?.data?.optionSets
        
        log.debug "optionSets: " + optionSets
        
        def optionSet
        if (optionSets.size() == 1) {
            optionSet = optionSets[0]
        }
        
        log.debug "optionSet: " + optionSet
        
        return optionSet
    }

    def findByName(def auth, def name, ArrayList<String> fields = [],
                   ApiVersion apiVersion = null) {

        return get(auth, name, fields, apiVersion)
    }
    
    def getLookup(def auth, ArrayList<String> fields = [":all", "options[id,code,name,displayName]"],
                  ApiVersion apiVersion = null) {

        def queryParams = [:]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }
        
        def lookup = [:]
        
        def allOptionSets = []
        
        def optionSets = apiService.get(auth, "${PATH}", queryParams, null, apiVersion)?.data?.optionSets
        
        if (optionSets) {
            allOptionSets.addAll(optionSets)
        
            // Create the lookup from the option sets
            allOptionSets.each { optionSet ->
                lookup << [("${optionSet.id}".toString()): optionSet]
            }
        }
        return lookup
    }
}
