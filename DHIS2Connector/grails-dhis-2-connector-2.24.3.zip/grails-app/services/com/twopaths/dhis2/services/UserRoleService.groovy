package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional
import groovyx.net.http.ContentType

@Transactional
class UserRoleService {

    final def PATH = "/userRoles"
    final def DATASET_SUBPATH="dataSets"
    final def PROGRAM_SUBPATH="programs"
    
    def apiService

    def findByRole(def auth, def role, ArrayList<String> fields = [],
                   ApiVersion apiVersion = null) {

        def queryParams = [filter: "name:eq:${role}"]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def userRoles = apiService.get(auth, "${PATH}", queryParams, null, apiVersion)?.data?.userRoles
        
        log.debug "userRoles: " + userRoles
            
        // Should only be one role....get that and return it
        if (userRoles?.size() == 1) {
            return userRoles[0]
        } else {
            return null
        }
    }
    
    def findByRoles(def auth, def roles, ArrayList<String> fields = [],
                    ApiVersion apiVersion = null) {
        
        // Need to use a queryString for the filter

        def queryParams = [:]

        if (fields?.size() > 0) {
            queryParams.put("fields", fields.join(','))
        }

        def queryString = ""
        roles.each { role -> 
            def encodedRole = java.net.URLEncoder.encode(role, "UTF-8")
            queryString += "&filter=name:eq:${encodedRole}"
        }
        if (queryString) {
            queryString = queryString.substring(1)
        }
        
        def userRoles = apiService.get(auth, "${PATH}", [:], queryString, apiVersion)?.data?.userRoles
        
        log.debug "userRoles: " + userRoles
        return userRoles
    }

    def assignDataSetToUserRole(def auth, def userRole, def dataSetId,
                                ApiVersion apiVersion = null) {

        def json = apiService.post(auth, "${PATH}/${userRole.id}/${DATASET_SUBPATH}/${dataSetId}")

        return json
    }

    def assignProgramToUserRole(def auth, def userRole, def programId,
                                ApiVersion apiVersion = null) {

        def json = apiService.post(auth, "${PATH}/${userRole.id}/${PROGRAM_SUBPATH}/${programId}",
                null, [:], ContentType.JSON, apiVersion)

        return json
    }

}
