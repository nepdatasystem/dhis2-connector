package com.twopaths.dhis2.services

import com.twopaths.dhis2.api.ApiVersion
import grails.transaction.Transactional
import groovyx.net.http.ContentType

@Transactional
class DataValueService {

    final def PATH = "/dataValueSets"

    def apiService

    def create(def auth, def dataValue, ApiVersion apiVersion = null) {

        def json = apiService.post(auth, PATH, dataValue, [:], ContentType.JSON, apiVersion)

        log.debug "<<< dataValue: " + dataValue

        return json

    }

    def read (def auth, def dataSetId, def orgUnitId, def limit = null,
              def startDate = "1970-01-01", def endDate="2100-01-01", def children = true,
              ApiVersion apiVersion = null) {

        def queryParams = [
                dataSet: dataSetId,
                orgUnit: orgUnitId,
                startDate: startDate,
                endDate: endDate,
                children: children
        ]

        if (limit && limit > 0) {
            queryParams.put("limit", limit)
        }

        def response = apiService.get(auth, PATH, queryParams, null, apiVersion)?.data

        response = response?.dataValues

        return response
    }
}
