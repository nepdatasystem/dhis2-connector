package com.twopaths.dhis2.services

import grails.transaction.Transactional
import groovyx.net.http.ContentType

@Transactional
class ResourceTableService {

    def PATH = "/api/resourceTables"
    def ANALYTICS_SUBPATH = "analytics"

    def apiService

    /*
    Within DHIS 2, the resource tables are also refreshed when generating the analytics tables, so no need to call
    this one directly if calling the generateAnalyticsTables
     */
    def generateResourceTables (def auth) {
        def response = apiService.post(auth, PATH, [], [:], ContentType.TEXT )?.data

        log.debug "generateResourceTables Response: " + response

        return response
    }

    /*
    This also regenerates the resource tables too
     */
    def generateAnalyticsTables (def auth) {
        def response = apiService.post(auth, "${PATH}/${ANALYTICS_SUBPATH}", [], [:], ContentType.TEXT)?.data

        log.debug "generateAnalyticsTables Response: " + response

        return response
    }

}
