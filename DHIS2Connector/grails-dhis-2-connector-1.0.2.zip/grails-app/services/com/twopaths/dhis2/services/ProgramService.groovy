package com.twopaths.dhis2.services

import grails.transaction.Transactional

@Transactional
class ProgramService {
    
    def PATH = "/api/programs"
    
    def apiService
	
	def create(def auth, def program) {
		
		def created = apiService.post(auth, PATH, program)
		
		log.debug "program: " + created
		
		return created
	}
    
    def update(def auth, def program) {
        apiService.put(auth, PATH, program, program.id, [strategy: "CREATE_AND_UPDATE"])
    }
    
    def findAll(def auth, def query=[fields: ":all"]) {
        
        def programs = apiService.get(auth, "${PATH}", query)?.data

        return programs
    }
    
    def get(def auth, def programId) {
            
       def program = apiService.get(auth, "${PATH}/${programId}")?.data
            
       log.debug "program: " + program
            
       return program
    }
}
